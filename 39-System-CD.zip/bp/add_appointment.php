<?php
require_once('./config.php');
$schedule = $_GET['schedule'];
?>
<div class="container-fluid">
<style>
 .required > span {
    color: red;
}
</style>
  
    <form action="" id="appointment-form">
        <input type="hidden" name="id" value="<?php echo isset($id) ? $id : '' ?>">
        <input type="hidden" name="schedule" value="<?php echo isset($schedule) ? $schedule : '' ?>">
        <dl>
            <dt class="text-muted">Schedule</dt>
            <dd class=" pl-3"><b><?= date("F d, Y",strtotime($schedule)) ?></b></dd>
        </dl>
        <hr>
        <div class="row">
            <div class="col-md-6">
                <fieldset>
                    <legend class="text-muted">Personal Information</legend>
                    <div class="form-group">
                        <label for="owner_name" class="control-label required">Contact Person<span>*</span></label>
                        <input type="text" name="owner_name" id="owner_name" class="form-control form-control-border" value ="<?php echo isset($owner_name) ? $owner_name : '' ?>" required placeholder="Firstname M.I Lastname">
                    </div>
                    <div class="form-group">
                        <label for="contact" class="control-label required">Mobile Number<span>*</span></label>
                        <input type="text" maxlength="11" name="contact" id="contact" class="form-control form-control-border" value="<?php echo isset($contact) ? $contact : '' ?>" oninput="validateNumber(this);" required placeholder="09x-xxxx-xxxx">
                    </div>
                    <div class="form-group">
                        <label for="email" class="control-label required">Email<span>*</span></label>
                        <input type="email" name="email" id="email" class="form-control form-control-border" value ="<?php echo isset($email) ? $email : '' ?>" required placeholder="name@email.com">
                    </div>
                    <div class="form-group">
                        <label for="address" class="control-label required">Address<span>*</span></label>
                        <textarea type="text" name="address" id="address" class="form-control form-control-sm rounded-0" rows="3" required placeholder="Street, Brgy, City"><?php echo isset($address) ? $address : '' ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="location" class="control-label required">Event Location<span>*</span></label>
                        <input type="text" name="location" id="location" class="form-control form-control-border" value ="<?php echo isset($location) ? $location : '' ?>" required placeholder="Photoshoot venue">
                    </div>
                    <div>
                    <label for="quantity"class="control-label required">Quantity<span>*</span></label>
                    <input type="text" maxlength="3" id="quantity"name="quantity"class="form-control form-control-border"value ="<?php echo isset($quantity) ? $quantity : '' ?>" required placeholder="Number of Packs">
                    <script>
    document.getElementById('quantity').addEventListener('input', function () {
        // Check if the input value is negative
        if (/^-?\d*$/.test(this.value)) {
        // Only allow positive numbers or an empty field
        if (parseInt(this.value) < 1) {
            this.value = ''; // If the value is negative, set it to an empty string
        }
    } else {
        // Clear the field if it contains non-numeric characters
        this.value = '';
    }
});
</script>   
                </div>   
                   
                </fieldset>
            </div>
            <div class="col-md-6">
            <div class="form-group">
                <br>
                <br>
                <label for="file_name" class="control-label required">Upload File (<span>doc, jpeg, png,docx, jpg</span>)</label>
                <form method="post" enctype="multipart/form-data" action="master.php">
                <input type="file" name="file" id="file_name" class="form-control form-control-border"<?php echo isset($file_name) ? $file_name : '' ?>" >
                
                </form>
                    </div>
                <fieldset>
                    <legend class="text-muted"></legend>
                    <div class="form-group">
                        <label for="category_id" class="control-label required">Types of Services<span>*</span></label>
                        <select name="category_id" id="category_id" class="form-control form-control-border select2">
                            <option value="" selected disabled></option>
                            <?php 
                            $categories = $conn->query("SELECT * FROM category_list where delete_flag = 0 ".(isset($category_id) && !empty($category_id) ? " or id = '{$category_id}'" : "")." order by name asc");
                            while($row = $categories->fetch_assoc()):
                            ?>
                            <option value="<?= $row['id'] ?>" <?= isset($category_id) && in_array($row['id'],explode(',', $category_id)) ? "selected" : "" ?> <?= $row['delete_flag'] == 1 ? "disabled" : "" ?>><?= ucwords($row['name']) ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>                    
                <div class="form-group">
                    <label for="service_id" class="control-label required">Service<span>*</span></label>
                    <?php 
                        $services = $conn->query("SELECT * FROM service_list where delete_flag = 0 ".(isset($service_id) && !empty($service_id) ? " or id in ('{$service_id}')" : "")." order by name asc");
                        while($row = $services->fetch_assoc()){
                            unset($row['description']);
                            $service_arr[] = $row;
                        }
                        ?>
                    <select name="service_id[]" id="service_id" class="form-control form-control-border select2" multiple>                    
                    </select>
                </div>
                </fieldset>
               
                
            </div>
        </div>
    </form>
</div>
<script>
    function validateNumber(input) {
    // Remove non-numeric characters from the input
    input.value = input.value.replace(/\D/g, '');
}
    var service = $.parseJSON('<?= json_encode($service_arr) ?>') || {};
    $(function(){
        $('#uni_modal').on('shown.bs.modal',function(){
            $('#category_id').select2({
                placeholder:"Please Select Type Of Services Here.",
                width:'100%',
                dropdownParent:$('#uni_modal')
            })
            $('#service_id').select2({ 
                placeholder:"Please Select Sevice(s) Here.",
                width:'100%',
                dropdownParent:$('#uni_modal')
            })
        })
        $('#category_id').change(function(){
            var id = $(this).val()
            $('#service_id').html('')
            $('#service_id').select2('destroy')
            Object.keys(service).map(function(k){
                if($.inArray(id,service[k].category_ids.split(',')) > -1 ){

                    var opt = $("<option>")
                        opt.val(service[k].id)
                        opt.text(service[k].name)
                    $('#service_id').append(opt)
                }
            })
            $('#service_id').select2({
                placeholder:"Please Select Sevice(s) Here.",
                width:'100%',
                dropdownParent:$('#uni_modal')
            })
            $('#service_id').val('').trigger('change')
        });
        $('#uni_modal #appointment-form').submit(function(e){
            e.preventDefault();
            var _this = $(this)
            $('.pop-msg').remove()
            var el = $('<div>')
                el.addClass("pop-msg alert")
                el.hide()
                var recaptchaResponse = grecaptcha.getResponse();
    if (!recaptchaResponse || recaptchaResponse.length === 0) {
        el.addClass("alert-danger");
        el.text("Please complete the reCAPTCHA verification.");
        _this.prepend(el);
        el.show('slow');
        $('html,body,.modal').animate({scrollTop:0},'fast');
        return;
    }
            start_loader();
            $.ajax({
                url:_base_url_+"classes/Master.php?f=save_appointment",
				data: new FormData($(this)[0]),
                cache: false,
                contentType: false,
                processData: false,
                method: 'POST',
                type: 'POST',
                dataType: 'json',
				error:err=>{
					console.log(err)
					alert_toast("An error occured",'error');
					end_loader();
				},
                success:function(resp){
                    if(resp.status == 'success'){
                    end_loader();
                        setTimeout(() => {
                            uni_modal("Success","success_msg.php?code="+resp.code)
                            
                        }, 750);
                    }else if(!!resp.msg){
                        el.addClass("alert-danger")
                        el.text(resp.msg)
                        _this.prepend(el)
                    }else{
                        el.addClass("alert-danger")
                        el.text("An error occurred due to unknown reason.")
                        _this.prepend(el)
                    }
                    el.show('slow')
                    $('html,body,.modal').animate({scrollTop:0},'fast')
                    end_loader();
                }
            })
        })
    })
</script>