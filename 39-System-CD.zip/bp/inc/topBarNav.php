

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <title>Your Page Title</title>
  <style>
    #top-Nav {
      position: fixed !important;
      top: 0 !important;
      padding: 1.5em 2.5em !important;
    }

    .text-sm .layout-navbar-fixed .wrapper .main-header~.content-wrapper,
    .layout-navbar-fixed .wrapper .main-header.text-sm~.content-wrapper {
      margin-top: calc(3.6) !important;
      padding-top: calc(3.2em) !important;
    }
  </style>
</head>

<body>

  <nav class="main-header navbar navbar-expand-lg navbar-dark border-0 text-sm bg-gradient-blue" id='top-Nav'>
    <div class="container">
      <a href="./" class="navbar-brand">
        <img src="<?php echo validate_image($_settings->info('logo')) ?>" alt="Site Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span><?= $_settings->info('short_name') ?></span>
      </a>

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav text-center">
          <li class="nav-item">
            <a href="./" class="nav-link <?= isset($page) && $page == 'home' ? "active" : "" ?>">Home</a>
          </li>
          <li class="nav-item">
            <a href="./?page=appointment" class="nav-link <?= isset($page) && $page == 'appointment' ? "active" : "" ?>">Add Schedule</a>
          </li>
          <li class="nav-item">
            <a href="./?page=services" class="nav-link <?= isset($page) && $page == 'services' ? "active" : "" ?>">Our Services</a>
          </li>
          <li class="nav-item">
            <a href="./?page=about" class="nav-link <?= isset($page) && $page == 'about' ? "active" : "" ?>">About Us</a>
          </li>
          <li class="nav-item">
            <a href="./?page=contact_us" class="nav-link <?= isset($page) && $page == 'contact_us' ? "active" : "" ?>">Contact Us</a>
          </li>
        </ul>
      </div>

      <div class="navbar-nav ml-auto">
        <!-- Right navbar links (if any) -->
      </div>
    </div>
  </nav>

</body>
<!-- /.navbar -->
<script>
 
</script>