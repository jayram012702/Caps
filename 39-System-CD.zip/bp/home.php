<style>
    .car-cover {
        width: 12em;
    }

    .car-item .col-auto {
        max-width: calc(100% - 12em) !important;
    }

    .car-item:hover {
        transform: translate(0, -4px);
        background: #a5a5a521;
    }

    .banner-img-holder {
        height: 25vh !important;
        width: 100%;
        overflow: hidden;
    }

    .banner-img {
        object-fit: scale-down;
        height: 100%;
        width: 100%;
        transition: transform 0.3s ease-in;
    }

    .car-item:hover .banner-img {
        transform: scale(1.3);
    }

    .welcome-content img {
        margin: 0.5em;
        max-width: 100%; /* Make sure images don't exceed their container */
        height: auto; /* Maintain aspect ratio */
    }

    /* Media query for smaller screens (mobile) */
    @media (max-width: 768px) {
        .car-cover,
        .car-item .col-auto {
            width: 100%; /* Make the car cover and item take the full width on smaller screens */
        }

        .banner-img-holder {
            height: auto !important; /* Allow the banner image holder to adjust its height based on content */
        }

        .banner-img {
            object-fit: contain; /* Ensure the entire image is visible, maintaining aspect ratio */
        }

        .car-item:hover .banner-img {
            transform: scale(1); /* Remove scaling on hover for smaller screens */
        }
    }
</style>
<div class="col-lg-12 py-5">
    <div class="contain-fluid">
        <div class="card card-outline card-lightblue shadow rounded-0">
            <div class="card-body rounded-0">
                <div class="container-fluid">
                    <h3 class="text-center">Welcome</h3>
                    <hr>
                    <div class="welcome-content">
                        <?php include("welcome.html") ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
