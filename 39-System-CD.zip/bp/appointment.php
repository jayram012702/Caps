<style>
    .fc-event-title-container{
        text-align:center;
        position: sticky;
        top: 0;
    }
    .fc-event-title.fc-sticky{
        font-size:2em;
        
    }
    .tc_item{
  padding: 20px 40px;
}
.tc_body{
  height: calc(100% - 170px);
  overflow: auto;
  padding-right: 40px;
}
tc_body ol li{
  margin-bottom: 15px;
}

.tc_body ol li h3{
  margin-bottom: 5px;
}

</style>
<?php 
$appointments = $conn->query("SELECT * FROM `appointment_list` where `status` = 1 and date(schedule) >= '".date("Y-m-d")."' ");
$appoinment_arr = [];
while($row = $appointments->fetch_assoc()){
    if(!isset($appoinment_arr[$row['schedule']])) $appoinment_arr[$row['schedule']] = 0;
    $appoinment_arr[$row['schedule']] += 1;
}
?>
<div class="content py-5">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card card-outline card-primary rounded-0 shadow">
                <div class="card-header rounded-0">
                    <h4 class="card-title">Schedule Availability</h4>
                </div>
                <div class="card-body">
                    <div id="appointmentCalendar"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Terms and Agreements Modal -->
<div class="modal fade" id="termsAndAgreementsModal" tabindex="-1" role="dialog" aria-labelledby="termsAndAgreementsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title" id="termsAndAgreementsModalLabel">Terms and Agreements</h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="tc_item tc_head flex_align_justify">
        <div class="icon flex_align_justify">
          <ion-icon name="terminal-outline"></ion-icon>
        </div>
        <div class="text">
          
          <p>Last updated on November 24, 2023</p>
        </div>
      </div>
            <div class="tc_item tc_body">
                <!-- Your terms and agreements content goes here -->
                <ol>
          <li>
            <h3>Inclusive Fees and Payment Structure</h3>
            <p>Our service package encompasses transportation, service, photo-ops (Pictorial Session), makeup artist, editing, and shipment fees.
For your convenience, we offer a two-installment payment option.
During the pictorial session, we require an initial payment of 50% of the total package cost.
The remaining balance must be settled upon the receipt of the complete package of framed products provided by our service.</p>
          </li>
          <li>
            <h3>Flexible Payment Arrangements</h3>
            <p>We recognize the importance of flexibility in payment arrangements and strive to accommodate our clients' unique needs.
By offering a split payment option, we aim to ensure that you can secure our services and finalize the transaction at a time that suits you.</p>
          </li>
          <li>
            <h3>Timely Delivery</h3>
            <p>Please be aware that our Photo and Framing Service Provider estimates a production, editing, and frame assembly turnaround time of 7-10 days, with the possibility of earlier delivery.
We assure you that our products will be delivered in advance of your graduation schedule.</p>
          </li>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Decline</button>
                <button type="button" class="btn btn-primary" id="acceptTermsBtn">Accept</button>
            </div>
        </div>
    </div>
</div>

<script>
    var calendar;
    var appointment = $.parseJSON('<?= json_encode($appoinment_arr) ?>') || {};
    var acceptedTerms = false; // To track if terms are accepted
    start_loader();

    $(function() {
    var date = new Date();
    var Calendar = FullCalendar.Calendar;

    calendar = new Calendar(document.getElementById('appointmentCalendar'), {
        headerToolbar: {
            left: false,
            center: 'title',
        },
        selectable: true,
        themeSystem: 'bootstrap',
        showNonCurrentDates: false,
        events: [
            {
                daysOfWeek: [0, 1, 2, 3, 4, 5, 6], // these recurrent events move separately
                title: '<?= $_settings->info('max_appointment') ?>',
                allDay: true,
            }
        ],
        eventClick: function(info) {
            if (acceptedTerms && $(info.el).find('.fc-event-title.fc-sticky').text() > 0) {
                // Open the "Set an Appointment" modal when the event is clicked
                uni_modal("Set an Appointment", "add_appointment.php?schedule=" + info.event.startStr, "mid-large");
            } else {
                // If terms are not accepted, open the terms modal
                $('#termsAndAgreementsModal').modal('show');
            }
        },
        validRange: {
            start: moment(date).add(1, 'day').format("YYYY-MM-DD"), // Exclude the current day
        },
        eventDidMount: function(info) {
    if (!!appointment[info.event.startStr]) {
        var available = parseInt(info.event.title) - parseInt(appointment[info.event.startStr]);
        var eventElement = $(info.el);

        // Set the background color based on the available slots
        if (available > 0) {
            eventElement.css('background-color', ''); // Reset background color
        } else {
            eventElement.css('background-color', 'red'); // Set background color to red
        }

        // Update the text content of the event to show the available slots
        eventElement.find('.fc-event-title.fc-sticky').text(available);
    }
            end_loader();
        },
        editable: true
    });

    // When the "Accept" button is clicked in the terms modal, set acceptedTerms to true
    $('#acceptTermsBtn').click(function() {
        acceptedTerms = true;
        $('#termsAndAgreementsModal').modal('hide');
    });

    calendar.render();
})

</script>




