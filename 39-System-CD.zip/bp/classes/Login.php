<?php
require_once '../config.php';

class Login extends DBConnection {
    private $settings;

    public function __construct(){
        global $_settings;
        $this->settings = $_settings;
        parent::__construct();
        ini_set('display_error', 1);
    }

    public function __destruct(){
        parent::__destruct();
    }

    // Actions class functionalities added into Login class
    function save_log($data = array()){
        if(count($data) > 0){
            extract($data);
            $sql = "INSERT INTO `logs` (`user_id`, `action_made`) VALUES ('{$user_id}', '{$action_made}')";
            $save = $this->conn->query($sql);
            if(!$save){
                die($sql." <br> ERROR:".$this->conn->error);
            }
        }
        return true;
    }

    public function index(){
        echo "<h1>Access Denied</h1> <a href='".base_url."'>Go Back.</a>";
    }

    // Existing login functionality
    public function login(){
        extract($_POST);
    
        // Check if the login attempts session variable is set
        if (!isset($_SESSION['login_attempts'])) {
            $_SESSION['login_attempts'] = 0;
            $_SESSION['last_login_attempt'] = time();
        }
    
        // Check if enough time has passed since the last login attempt
        $time_since_last_attempt = time() - $_SESSION['last_login_attempt'];
        $reset_time = 10; // 5 minutes in seconds
    
        if ($time_since_last_attempt > $reset_time) {
            $_SESSION['login_attempts'] = 0;
        }
    
        // Check if the maximum login attempts are reached
        if ($_SESSION['login_attempts'] >= 3) {
            $time_left = max(0, $reset_time - $time_since_last_attempt);
            return json_encode(array('status' => 'max_attempts', 'time_left' => $time_left));
        }
    
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE username = ? AND password = ?");
        $pw = md5($password);
        $stmt->bind_param('ss', $username, $pw);
        $stmt->execute();
        $qry = $stmt->get_result();
    
        if ($qry->num_rows > 0) {
            $res = $qry->fetch_array();
    
            if ($res['status'] != 1) {
                return json_encode(array('status' => 'not_verified'));
            }
    
            foreach ($res as $k => $v) {
                if (!is_numeric($k) && $k != 'password') {
                    $this->settings->set_userdata($k, $v);
                }
            }
    
            $_SESSION['id'] = $res['id'];
            $this->settings->set_userdata('login_type', 1); 
            $log['user_id'] = $res['id'];
            $log['action_made'] = "Logged in the system.";
            
            $this->save_log($log); // Log the action
    
            // Reset login attempts on successful login
            unset($_SESSION['login_attempts']);
            unset($_SESSION['last_login_attempt']);
    
            return json_encode(array('status' => 'success'));
        } else {
            // Increment login attempts
            $_SESSION['login_attempts']++;
            $_SESSION['last_login_attempt'] = time();
    
            // Check if the maximum login attempts are reached
            if ($_SESSION['login_attempts'] >= 3) {
                $time_left = max(0, $reset_time - $time_since_last_attempt);
                return json_encode(array('status' => 'max_attempts', 'time_left' => $time_left));
            }
    
            return json_encode(array('status' => 'incorrect', 'error' => $this->conn->error));
        }
    }
    

    // Existing logout functionality
    function logout(){
        if (isset($_SESSION['id'])) {
            $log['user_id'] = $_SESSION['id'];
            $log['action_made'] = "Logged out.";
            // audit log
            $this->save_log($log);
        }
        session_destroy();
        header("location:/bp/admin/login.php");
    }

    // Existing client login functionality
    function client_login(){
        extract($_POST);
        $stmt = $this->conn->prepare("SELECT *,concat(lastname,', ',firstname,' ',middlename) as fullname from client_list where email = ? and `password` = ? ");
        $pw = md5($password);
        $stmt->bind_param('ss', $email, $pw);
        $stmt->execute();
        $qry = $stmt->get_result();
        if($this->conn->error){
            $resp['status'] = 'failed';
            $resp['msg'] = "An error occurred while fetching data. Error:". $this->conn->error;
        } else {
            // ... (existing logic)
        }
        return json_encode($resp);
    }

    // Existing client logout functionality
    public function client_logout(){
        if($this->settings->sess_des()){
            redirect('./login.php');
        }
    }
}

$action = !isset($_GET['f']) ? 'none' : strtolower($_GET['f']);
$auth = new Login();

// Handling actions based on the query parameter
switch ($action) {
    case 'login':
        echo $auth->login();
        break;
    case 'logout':
        echo $auth->logout();
        break;
    case 'client_login':
        echo $auth->client_login();
        break;
    case 'client_logout':
        echo $auth->client_logout();
        break;
    default:
        echo $auth->index();
        break;
}
?>
