<?php
require_once('../config.php');
Class Master extends DBConnection {
	private $settings;
	public function __construct(){
		global $_settings;
		$this->settings = $_settings;
		parent::__construct();
	}
	public function __destruct(){
		parent::__destruct();
	}
	function capture_err(){
		if(!$this->conn->error)
			return false;
		else{
			$resp['status'] = 'failed';
			$resp['error'] = $this->conn->error;
			return json_encode($resp);
			
		}
	}
		    function save_log($data=array()){
	        // Data array paramateres
	            // user_id = user unique id
	            // action_made = action made by the user
 
	        if(count($data) > 0){
	            extract($data);
	            $sql = "INSERT INTO `logs` (`user_id`,`action_made`) VALUES ('{$user_id}','{$action_made}')";
	            $save = $this->conn->query($sql);
	            if(!$save){
	                die($sql." <br> ERROR:".$this->conn->error);
	            }
	        }
	        return true;
	    }
	function save_message(){
		extract($_POST);
		$data = "";
		foreach($_POST as $k =>$v){
			if(!in_array($k,array('id'))){
				if(!is_numeric($v))
					$v = $this->conn->real_escape_string($v);
				if(!empty($data)) $data .=",";
				$data .= " `{$k}`='{$v}' ";
			}
		}
		if(empty($id)){
			$sql = "INSERT INTO `message_list` set {$data} ";
		}else{
			$sql = "UPDATE `message_list` set {$data} where id = '{$id}' ";
		}
		
		$save = $this->conn->query($sql);
		if($save){
			$rid = !empty($id) ? $id : $this->conn->insert_id;
			$resp['status'] = 'success';
			if(empty($id))
				$resp['msg'] = "Your message has successfully sent.";
			else
				$resp['msg'] = "Message details has been updated successfully.";
		}else{
			$resp['status'] = 'failed';
			$resp['msg'] = "An error occured.";
			$resp['err'] = $this->conn->error."[{$sql}]";
		}
		if($resp['status'] =='success' && !empty($id))
		$this->settings->set_flashdata('success',$resp['msg']);
		if($resp['status'] =='success' && empty($id))
		$this->settings->set_flashdata('pop_msg',$resp['msg']);
		return json_encode($resp);
	}
	function delete_message(){
		extract($_POST);
		$del = $this->conn->query("DELETE FROM `message_list` where id = '{$id}'");
		if($del){
			$resp['status'] = 'success';
			$this->settings->set_flashdata('success',"Message has been deleted successfully.");

		}else{
			$resp['status'] = 'failed';
			$resp['error'] = $this->conn->error;
		}
		return json_encode($resp);

	}
	function save_category(){
		extract($_POST);
		$data = "";
		foreach($_POST as $k =>$v){
			if(!in_array($k,array('id'))){
				if(!is_numeric($v))
					$v = $this->conn->real_escape_string($v);
				if(!empty($data)) $data .=",";
				$data .= " `{$k}`='{$v}' ";
			}
		}
		if(empty($id)){
			$sql = "INSERT INTO `category_list` set {$data} ";
		}else{
			$sql = "UPDATE `category_list` set {$data} where id = '{$id}' ";
		}
		$check = $this->conn->query("SELECT * FROM `category_list` where `name` = '{$name}' and delete_flag = 0 ".($id > 0 ? " and id != '{$id}'" : ""));
		if($check->num_rows > 0){
			$resp['status'] = 'failed';
			$resp['msg'] = "Category name already exists.";
		}else{
			$save = $this->conn->query($sql);
			if($save){
				$rid = !empty($id) ? $id : $this->conn->insert_id;
				$resp['status'] = 'success';
				if(empty($id))
					$resp['msg'] = "Category has successfully added.";
				else
					$resp['msg'] = "Category details has been updated successfully.";
			}else{
				$resp['status'] = 'failed';
				$resp['msg'] = "An error occured.";
				$resp['err'] = $this->conn->error."[{$sql}]";
			}
		}
		if($resp['status'] =='success')
			$this->settings->set_flashdata('success',$resp['msg']);
		return json_encode($resp);
	}
	function delete_category(){
		extract($_POST);
		$del = $this->conn->query("UPDATE `category_list` set delete_flag=1 where id = '{$id}'");
		if($del){
			$resp['status'] = 'success';
			$this->settings->set_flashdata('success',"Category has been deleted successfully.");
		}else{
			$resp['status'] = 'failed';
			$resp['error'] = $this->conn->error;
		}
		return json_encode($resp);
	}
	function save_service(){
		$_POST['category_ids'] = implode(',',$_POST['category_ids']);
		extract($_POST);
		$data = "";
		foreach($_POST as $k =>$v){
			if(!in_array($k,array('id'))){
				if(!is_numeric($v))
					$v = $this->conn->real_escape_string($v);
				if(!empty($data)) $data .=",";
				$data .= " `{$k}`='{$v}' ";
			}
		}
		if(empty($id)){
			$sql = "INSERT INTO `service_list` set {$data} ";
		}else{
			$sql = "UPDATE `service_list` set {$data} where id = '{$id}' ";
		}
		$check = $this->conn->query("SELECT * FROM `service_list` where `name` ='{$name}' and category_ids = '{$category_ids}' and delete_flag = 0 ".($id > 0 ? " and id != '{$id}' " : ""))->num_rows;
		if($check > 0){
			$resp['status'] = 'failed';
			$resp['msg'] = "Service already exists.";
		}else{
			$save = $this->conn->query($sql);
			if($save){
				$rid = !empty($id) ? $id : $this->conn->insert_id;
				$resp['status'] = 'success';
				if(empty($id))
					$resp['msg'] = "Service has successfully added.";
				else
					$resp['msg'] = "Service has been updated successfully.";
			}else{
				$resp['status'] = 'failed';
				$resp['msg'] = "An error occured.";
				$resp['err'] = $this->conn->error."[{$sql}]";
			}
			if($resp['status'] =='success')
			$this->settings->set_flashdata('success',$resp['msg']);
		}
		return json_encode($resp);
	}

//
function save_payment(){
	extract($_POST);
	$data = "";
	foreach($_POST as $k =>$v){
		if(!in_array($k,array('id'))){
			if(!is_numeric($v))
				$v = $this->conn->real_escape_string($v);
			if(!empty($data)) $data .=",";
			$data .= " `{$k}`='{$v}' ";
		}
	}
	if(empty($id)){
		$sql = "INSERT INTO `payment_list` set {$data} ";
	}else{
		$sql = "UPDATE `payment_list` set {$data} where id = '{$id}' ";
	}
	$check = $this->conn->query("SELECT * FROM `payment_list` where `name` = '{$name}' and delete_flag = 0 ".($id > 0 ? " and id != '{$id}'" : ""));
	if($check->num_rows > 0){
		$resp['status'] = 'failed';
		$resp['msg'] = "Payment name already exists.";
	}else{
		$save = $this->conn->query($sql);
		if($save){
			$rid = !empty($id) ? $id : $this->conn->insert_id;
			$resp['status'] = 'success';
			if(empty($id))
				$resp['msg'] = "payment has successfully added.";
			else
				$resp['msg'] = "payment details has been updated successfully.";
		}else{
			$resp['status'] = 'failed';
			$resp['msg'] = "An error occured.";
			$resp['err'] = $this->conn->error."[{$sql}]";
		}
	}
	if($resp['status'] =='success')
		$this->settings->set_flashdata('success',$resp['msg']);
	return json_encode($resp);
}
function delete_payment(){
	extract($_POST);
	$del = $this->conn->query("UPDATE `payment_list` set delete_flag=1 where id = '{$id}'");
	if($del){
		$resp['status'] = 'success';
		$this->settings->set_flashdata('success',"Payment has been deleted successfully.");
	}else{
		$resp['status'] = 'failed';
		$resp['error'] = $this->conn->error;
	}
	return json_encode($resp);
}

//
	function delete_service(){
		extract($_POST);
		$del = $this->conn->query("UPDATE `service_list` set delete_flag = 1 where id = '{$id}'");
		if($del){
			$resp['status'] = 'success';
			$this->settings->set_flashdata('success',"Service has been deleted successfully.");

		}else{
			$resp['status'] = 'failed';
			$resp['error'] = $this->conn->error;
		}
		return json_encode($resp);
	}
	
	function save_appointment() {
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "bp_db";
	
		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);
	
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		}
	
		$resp = array(); // Initialize response array
		$requiredFields = array('owner_name', 'contact', 'email', 'address', 'location', 'quantity', 'category_id','service_id');
		$missingFields = array(); // Initialize an array to store missing fields
	
		foreach ($requiredFields as $field) {
			if (empty($_POST[$field])) {
				$fieldLabel = ($field === 'category_id') ? 'Types of Services' : (($field === 'service_id') ? 'Service' : $field);
				$missingFields[] = $fieldLabel;
			}
		}
	
		if (!empty($missingFields)) {
			$resp['status'] = 'failed';
			$resp['msg'] = "Required fields are missing: " . implode(', ', $missingFields);
			return json_encode($resp);
		}
		if (empty($_POST['owner_name']) || empty($_POST['contact']) || empty($_POST['email']) || empty($_POST['address']) || empty($_POST['location']) || empty($_POST['quantity'])) {
			$resp['status'] = 'failed';
			$resp['msg'] = "Required fields are missing.";
			return json_encode($resp);
		}
		
		// Add an additional check for email validation
		if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) || strpos($_POST['email'], '@') === false) {
			$resp['status'] = 'failed';
			$resp['msg'] = "Invalid email address format.";
			return json_encode($resp);
		}
		$contactNumber = $_POST['contact'];
		if (!preg_match('/^09\d{9}$/', $contactNumber)) {
			$resp['status'] = 'failed';
			$resp['msg'] = "Invalid contact number. Please enter a valid 11-digit number starting with '09'.";
			return json_encode($resp);
		}
	
		$appointmentIds = null; // Initializing the variable to avoid errors
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$targetDirectory = "../uploads/";
			
	
		}
		if (empty($_POST['id'])) {
			$prefix = "BP-" . date("Ym");
			$code = sprintf("%'.04d", 1);
			while (true) {
				$check = $conn->query("SELECT * FROM `appointment_list` where code = '{$prefix}{$code}' ")->num_rows;
				if ($check <= 0) {
					$_POST['code'] = $prefix . $code;
					break;
				} else {
					$code = sprintf("%'.04d", ceil($code) + 1);
				}
			}
		}
	
		$_POST['service_ids'] = implode(",", $_POST['service_id']);
		extract($_POST);
	
		$data = "";
		foreach ($_POST as $k => $v) {
			if ($k !== 'id' && !is_array($_POST[$k])) {
				if (!is_numeric($v))
					$v = $conn->real_escape_string($v);
				if (!empty($data)) $data .= ",";
				$data .= " `{$k}`='{$v}' ";
			}
		}
	
		if (empty($id)) {
			$sql = "INSERT INTO `appointment_list` set {$data} ";
		} else {
			$sql = "UPDATE `appointment_list` set {$data} where id = '{$id}' ";
		}
	
		$slot_taken = $conn->query("SELECT * FROM `appointment_list` where date(schedule) = '{$schedule}' and `status` = 1")->num_rows;
	
		if ($slot_taken >= $this->settings->info('max_appointment')) {
			$resp['status'] = 'failed';
			$resp['msg'] = "Sorry, the Appointment Schedule is already full.";
		} else {
			$save = $conn->query($sql);
			if ($save) {
				$rid = !empty($id) ? $id : $conn->insert_id;
				$resp['id'] = $rid;
				$resp['code'] = $code;
				$resp['status'] = 'success';
				if (empty($id)) {
					$resp['msg'] = "New Appointment Details have been successfully added.";
				} else {
					$resp['msg'] = "Appointment Details have been updated successfully.";
				}
			} else {
				$resp['status'] = 'failed';
				$resp['msg'] = "An error occurred: " . $conn->error . " [{$sql}]";
			}
		}
	
		if ($resp['status'] == 'success') {
			$this->settings->set_flashdata('success', $resp['msg']);
		}
	
	
		if (isset($_FILES['file'])) {
			$file = $_FILES['file'];
			$fileName = $file['name'];
			$fileTmpName = $file['tmp_name'];
			$fileSize = $file['size'];
			$fileType = $file['type'];
			$appointmentIds = $resp['id'];

			$allowedExtensions = array("doc", "jpeg", "png","docx", "jpg");
			$fileExtension = pathinfo($fileName, PATHINFO_EXTENSION);

			if (in_array($fileExtension, $allowedExtensions)) {
				// Check for unique file name to prevent overwriting
				$targetFile = $targetDirectory . basename($fileName);
				$counter = 1;

				while (file_exists($targetFile)) {
					$fileName = pathinfo($file['name'], PATHINFO_FILENAME) . '_' . $counter . '.' . $fileExtension;
					$targetFile = $targetDirectory . $fileName;
					$counter++;
				}	

				if (move_uploaded_file($fileTmpName, $targetFile)) {
					$sql = "INSERT INTO uploaded_files (file_name, file_path, file_type, appointment_ids) VALUES ('$fileName', '$targetFile', '$fileType','$appointmentIds')";

					if ($conn->query($sql) === TRUE) {
						$resp['upload_status'] = 'success';
						$resp['upload_msg'] = "File uploaded successfully and record added to the database.";
					} else {
						$resp['upload_status'] = 'failed';
						$resp['upload_msg'] = "Error: " . $sql . "<br>" . $conn->error;
					}
				} else {
					$resp['upload_status'] = 'failed';
					$resp['upload_msg'] = "Sorry, there was an error uploading your file.";
				}
			} else {
				$resp['upload_status'] = 'failed';
				$resp['upload_msg'] = "Sorry, only DOC, JPEG, and PNG files are allowed.";
			}
		}
	
		$conn->close(); // Close the database connection
	
		return json_encode($resp);
	}
	
	function delete_appointment() {
		extract($_POST);
		$resp = array();
	
		$del_files = $this->conn->query("DELETE FROM `uploaded_files` WHERE appointment_ids = '{$id}'");
		$del_appointment = $this->conn->query("DELETE FROM `appointment_list` WHERE id = '{$id}'");
	
		if ($del_files && $del_appointment) {
			$resp['status'] = 'success';
			$this->settings->set_flashdata('success', "Appointment Details have been deleted successfully.");
		} else {
			$resp['status'] = 'failed';
			$resp['error'] = $this->conn->error;
		}
		$user_id = $_SESSION['id']; 
		$log['user_id'] = $user_id;
		$log['action_made'] = "Deleted the appointment ID: {$id}.";
		// audit log
		$this->save_log($log);
		return json_encode($resp);
	}
	
	
	
	
	function update_appointment_status() {
		extract($_POST);
		$del = $this->conn->query("UPDATE `appointment_list` SET `status` = '{$status}' WHERE id = '{$id}'");
	
		if ($del) {
			$resp['status'] = 'success';
			$this->settings->set_flashdata('success', "Appointment Request status has successfully updated.");
	
			$get_appointment_query = $this->conn->query("SELECT `contact`, `owner_name`, `code` FROM `appointment_list` WHERE id = '{$id}'");
			$appointment = $get_appointment_query->fetch_assoc();
	
			if ($appointment && isset($appointment['contact'])) {
				$recipient_number = $appointment['contact'];
				$customer_name = $appointment['owner_name'];
				$customer_code = $appointment['code'];
	
				$ch = curl_init();
				$parameters = array(
					'apikey' => '1a1e57d7ac80579cd54afb4e60a3973c',
					'number' => $recipient_number,
					'sendername' => 'BPStudio'
				);
	
				if ($status == '1') {
					// Code for status 1 (approved)
					$parameters['message'] = "Bellepepper Studio: Hi {$customer_name}, this is to inform you that your appointment request has been approved with the code {$customer_code}. please check your email for further details of the transactions, thank you!";
				} elseif ($status == '2') {
					// Code for status 2 (cancelled)
					$parameters['message'] = "Bellepepper Studio: Hi {$customer_name}, this is to inform you that your appointment request has been cancelled. If you have any questions, please contact us. Thank you!";
				}
	
				curl_setopt($ch, CURLOPT_URL, 'https://semaphore.co/api/v4/messages');
				curl_setopt($ch, CURLOPT_POST, 1);
				curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($parameters));
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	
				$output = curl_exec($ch);
				curl_close($ch);
	
				// Check for an error in sending the message
				if ($output === false) {
					$resp['status'] = 'failed';
					$resp['error'] = 'Error occurred while sending the message.';
				} else {
					$resp['status'] = 'success';
					$resp['msg'] = 'Message successfully sent.';
				}
			} else {
				$resp['status'] = 'failed';
				$resp['error'] = 'Contact not found or empty for the appointment.';
			}
	
		} else {
			$resp['status'] = 'failed';
			$resp['error'] = $this->conn->error;
		}
	
		$user_id = $_SESSION['id'];
		$log['user_id'] = $user_id;
		$log['action_made'] = "Updated the status into {$status} of appointment ID: {$id}.";
		// audit log
		$this->save_log($log);
		return json_encode($resp);
	}
	
	
	
	
	

	}
	

	
	


$Master = new Master();
$action = !isset($_GET['f']) ? 'none' : strtolower($_GET['f']);
$sysset = new SystemSettings();
switch ($action) {
	case 'save_appointment':
		echo $Master->save_appointment();
	break;
	case 'delete_appointment':
		echo $Master->delete_appointment();
	break;
	case 'update_appointment_status':
		echo $Master->update_appointment_status();
	break;
	case 'save_message':
		echo $Master->save_message();
	break;
	case 'delete_message':
		echo $Master->delete_message();
	break;
	case 'save_category':
		echo $Master->save_category();
	break;
	case 'delete_category':
		echo $Master->delete_category();
	break;
	case 'save_payment':
		echo $Master->save_payment();
	break;
	case 'delete_payment':
		echo $Master->delete_payment();
	break;
	case 'save_service':
		echo $Master->save_service();
	break;
	case 'delete_service':
		echo $Master->delete_service();
	break;
	default:
		// echo $sysset->index();
		break;
}

?>