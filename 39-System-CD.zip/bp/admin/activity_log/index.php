
<div class="card card-outline card-primary ">
<div class="card-header d-flex w-100">
	        <h3 class="card-title col-auto flex-grow-1"><b>Activity Log</b></h3>
	        <button class="btn btn-sm btn-primary rounded-0 " type="button" onclick="location.reload()"><i class="fa fa-retweet "></i> Refresh List</button>
	    </div>
	    
	    <div class="card-body">
		<div class="container-fluid">
	        <div class="container-fluid">
	            <table class="table table-hover table-striped  table-bordered">
				<colgroup>
					
					<col width="25%">
					<col width="25%">
					<col width="25%">
					<col width="25%">
				</colgroup>
	                <thead>
	                    <tr>
	                        <th class="py-1 px-2">#</th>
	                        <th class="py-1 px-2">DateTime</th>
	                        <th class="py-1 px-2">Username</th>
	                        <th class="py-1 px-2">Action Made</th>
	                    </tr>
	                </thead>
	                <tbody>
	                    <?php 
						$i = 1;
	                    $qry = $conn->query("SELECT l.*,u.username FROM `logs` l inner join users u on l.user_id = u.id order by  unix_timestamp(l.`date_created`) asc");
	                    
	                    while($row=$qry->fetch_assoc()):
	                    ?>
	                    <tr>
	                        <td class="py-1 px-2"><?php echo $i++ ?></td>
	                        <td class="py-1 px-2"><?php echo date("M d, Y H:i",strtotime($row['date_created'])) ?></td>
	                        <td class="py-1 px-2"><?php echo $row['username'] ?></td>
	                        <td class="py-1 px-2"><?php echo $row['action_made'] ?></td>
	                    </tr>
	                    <?php endwhile; ?>
	                    <?php if($qry->num_rows <=0): ?>
	                        <tr>
	                            <th class="tex-center"  colspan="4">No data to display.</th>
	                        </tr>
							
	                    <?php endif; ?>
	                </tbody>
	            </table>
	        </div>
	    </div>
	</div>
	<script>
		  $(document).ready(function(){
      $('.table').DataTable({
         "order": [[0, "asc"]], // Default sorting by the first column in ascending order
         "paging": true, // Enable pagination
         "lengthChange": true, // Enable the ability to change the number of rows displayed
         "searching": true, // Enable search box
         "info": true, // Display information about the table
         "autoWidth": false // Disable auto-width calculation
      });
   });
		
		</script>