

CREATE TABLE `appointment_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `code` varchar(100) NOT NULL,
  `schedule` date NOT NULL,
  `owner_name` text NOT NULL,
  `contact` text NOT NULL,
  `email` text NOT NULL,
  `address` text NOT NULL,
  `category_id` int(30) NOT NULL,
  `quantity` int(11) NOT NULL,
  `location` varchar(50) NOT NULL,
  `service_ids` text DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `appointment_list_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category_list` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4;

INSERT INTO appointment_list VALUES("36","BP-2023110001","2023-01-05","asd","123","123","123","12","123","123","8","3","2023-11-05 20:04:18","2023-11-05 20:08:02");
INSERT INTO appointment_list VALUES("37","BP-2023110001","2023-02-05","asd","123","123","123","12","300","123","8","3","2023-11-05 20:04:18","2023-11-05 20:16:53");
INSERT INTO appointment_list VALUES("38","BP-2023110001","2023-03-05","asd","123","123","123","12","150","123","8","3","2023-02-05 20:04:18","2023-11-05 20:17:10");
INSERT INTO appointment_list VALUES("39","BP-2023110001","2023-04-05","asd","123","123","123","12","170","123","8","3","2023-11-05 20:04:18","2023-11-05 20:17:13");
INSERT INTO appointment_list VALUES("40","BP-2023110001","2023-05-05","asd","123","123","123","12","200","123","8","3","2023-11-05 20:04:18","2023-11-05 20:17:24");
INSERT INTO appointment_list VALUES("41","BP-2023110001","2023-06-05","asd","123","123","123","12","100","123","8","3","2023-11-05 20:04:18","2023-11-05 20:17:28");
INSERT INTO appointment_list VALUES("42","BP-2023110001","2023-07-05","asd","123","123","123","12","50","123","8","3","2023-11-05 20:04:18","2023-11-05 20:17:32");
INSERT INTO appointment_list VALUES("43","BP-2023110001","2023-08-05","asd","123","123","123","12","250","123","8","3","2023-11-05 20:04:18","2023-11-05 20:17:46");
INSERT INTO appointment_list VALUES("44","BP-2023110001","2023-09-05","asd","123","123","123","12","280","123","8","3","2023-11-05 20:04:18","2023-11-05 20:17:56");
INSERT INTO appointment_list VALUES("45","BP-2023110001","2023-10-05","asd","123","123","123","12","220","123","8","3","2023-11-05 20:04:18","2023-11-05 20:18:03");
INSERT INTO appointment_list VALUES("47","BP-2023110002","2023-11-05","jayram reynaldo","09684737578","jayramreynaldo@gmail.com","bria homes","12","50","calamba bayan","8","1","2023-11-05 20:21:51","2023-11-09 15:35:43");
INSERT INTO appointment_list VALUES("49","BP-2023110003","2023-11-06","kian franciss aquino","09265944125","kianaquino10@gmail.com","majada","12","30","mayapa","8","0","2023-11-05 20:46:35","2023-11-06 16:06:53");
INSERT INTO appointment_list VALUES("50","BP-2023110004","2023-11-07","Mark Gio Jopia","09503673249","markgiojopia@gmail.com","mamatid","12","50","sancristobal","8","2","2023-11-05 20:47:25","2023-11-15 10:46:12");
INSERT INTO appointment_list VALUES("60","BP-2023110005","2023-11-18","pacqiou manny","09999999999","jejejejey@asd","calamaba","12","12","calmaab","8","3","2023-11-18 15:09:38","2023-11-18 17:20:43");
INSERT INTO appointment_list VALUES("61","BP-2023110006","2023-11-19","jayram reynaldo","09503673249","mpjopia@ccc.edu.ph","San Cristobal, Calamba","12","3","Pansol","8","1","2023-11-18 17:10:39","2023-11-18 17:13:33");



CREATE TABLE `category_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 = Active, 1 = Delete',
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;

INSERT INTO category_list VALUES("7","Printing Services","1","2023-06-08 20:47:27","");
INSERT INTO category_list VALUES("8","Photoshoot Services","1","2023-06-08 20:47:42","");
INSERT INTO category_list VALUES("9","Framing services","1","2023-06-08 20:47:52","");
INSERT INTO category_list VALUES("11","Photoshoot, Printing, Framing","1","2023-07-04 18:33:15","");
INSERT INTO category_list VALUES("12","Photoshoot Services","0","2023-11-03 00:25:33","");



CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(30) NOT NULL,
  `action_made` text NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=327 DEFAULT CHARSET=utf8mb4;

INSERT INTO logs VALUES("1","4","Logged in the system.","2023-11-09 00:05:26");
INSERT INTO logs VALUES("2","4","Logged in the system.","2023-11-09 00:05:40");
INSERT INTO logs VALUES("13","4","Logged in the system.","2023-11-09 00:19:19");
INSERT INTO logs VALUES("14","4","Logged in the system.","2023-11-09 00:20:25");
INSERT INTO logs VALUES("17","4","Logged in the system.","2023-11-09 00:28:37");
INSERT INTO logs VALUES("18","4","Logged in the system.","2023-11-09 00:35:45");
INSERT INTO logs VALUES("19","4","Logged in the system.","2023-11-09 00:35:50");
INSERT INTO logs VALUES("20","4","Logged out.","2023-11-09 00:36:23");
INSERT INTO logs VALUES("21","4","Logged in the system.","2023-11-09 00:37:05");
INSERT INTO logs VALUES("23","4","Logged in the system.","2023-11-09 00:37:13");
INSERT INTO logs VALUES("29","4","Logged in the system.","2023-11-09 00:38:21");
INSERT INTO logs VALUES("31","4","Logged in the system.","2023-11-09 00:38:52");
INSERT INTO logs VALUES("32","4","Logged in the system.","2023-11-09 00:38:57");
INSERT INTO logs VALUES("34","4","Logged in the system.","2023-11-09 00:40:19");
INSERT INTO logs VALUES("36","4","Logged in the system.","2023-11-09 00:41:01");
INSERT INTO logs VALUES("37","4","Logged in the system.","2023-11-09 00:41:05");
INSERT INTO logs VALUES("38","4","Logged in the system.","2023-11-09 00:41:38");
INSERT INTO logs VALUES("40","4","Logged in the system.","2023-11-09 00:48:51");
INSERT INTO logs VALUES("49","4","Logged in the system.","2023-11-09 01:16:50");
INSERT INTO logs VALUES("50","4","Logged in the system.","2023-11-09 01:16:52");
INSERT INTO logs VALUES("51","4","Logged in the system.","2023-11-09 01:16:53");
INSERT INTO logs VALUES("52","4","Logged in the system.","2023-11-09 01:17:11");
INSERT INTO logs VALUES("53","4","Logged out.","2023-11-09 01:17:16");
INSERT INTO logs VALUES("54","4","Logged in the system.","2023-11-09 01:17:21");
INSERT INTO logs VALUES("55","4","Logged in the system.","2023-11-09 09:04:09");
INSERT INTO logs VALUES("63","4","Logged in the system.","2023-11-09 09:29:30");
INSERT INTO logs VALUES("69","4","Logged in the system.","2023-11-09 09:34:59");
INSERT INTO logs VALUES("75","4","Logged in the system.","2023-11-09 09:44:33");
INSERT INTO logs VALUES("76","4","Logged in the system.","2023-11-09 10:24:05");
INSERT INTO logs VALUES("77","4","Logged in the system.","2023-11-09 13:58:30");
INSERT INTO logs VALUES("79","4","Logged in the system.","2023-11-09 14:18:42");
INSERT INTO logs VALUES("81","4","Logged in the system.","2023-11-09 15:09:48");
INSERT INTO logs VALUES("82","4","Logged out.","2023-11-09 15:10:51");
INSERT INTO logs VALUES("83","4","Logged in the system.","2023-11-09 15:11:10");
INSERT INTO logs VALUES("84","4","Logged out.","2023-11-09 15:11:50");
INSERT INTO logs VALUES("85","4","Logged in the system.","2023-11-09 15:12:46");
INSERT INTO logs VALUES("86","4","Logged out.","2023-11-09 15:12:53");
INSERT INTO logs VALUES("87","4","Logged in the system.","2023-11-09 15:13:10");
INSERT INTO logs VALUES("88","4","Logged out.","2023-11-09 15:13:12");
INSERT INTO logs VALUES("89","4","Logged in the system.","2023-11-09 15:13:21");
INSERT INTO logs VALUES("90","4","Logged out.","2023-11-09 15:13:25");
INSERT INTO logs VALUES("91","4","Logged in the system.","2023-11-09 15:14:10");
INSERT INTO logs VALUES("92","4","Logged out.","2023-11-09 15:14:11");
INSERT INTO logs VALUES("93","4","Logged in the system.","2023-11-09 15:14:29");
INSERT INTO logs VALUES("94","4","Logged out.","2023-11-09 15:15:08");
INSERT INTO logs VALUES("95","4","Logged in the system.","2023-11-09 15:15:27");
INSERT INTO logs VALUES("96","4","Logged out.","2023-11-09 15:15:29");
INSERT INTO logs VALUES("97","4","Logged in the system.","2023-11-09 15:15:32");
INSERT INTO logs VALUES("98","4","Logged out.","2023-11-09 15:15:38");
INSERT INTO logs VALUES("99","4","Logged in the system.","2023-11-09 15:16:04");
INSERT INTO logs VALUES("100","4","Logged out.","2023-11-09 15:16:06");
INSERT INTO logs VALUES("101","4","Logged in the system.","2023-11-09 15:16:52");
INSERT INTO logs VALUES("102","4","Logged out.","2023-11-09 15:16:54");
INSERT INTO logs VALUES("103","4","Logged in the system.","2023-11-09 15:17:04");
INSERT INTO logs VALUES("104","4","Logged out.","2023-11-09 15:17:06");
INSERT INTO logs VALUES("105","4","Logged in the system.","2023-11-09 15:17:23");
INSERT INTO logs VALUES("106","4","Logged out.","2023-11-09 15:17:25");
INSERT INTO logs VALUES("107","4","Logged in the system.","2023-11-09 15:17:27");
INSERT INTO logs VALUES("108","4","Logged out.","2023-11-09 15:40:00");
INSERT INTO logs VALUES("109","4","Logged in the system.","2023-11-09 16:34:59");
INSERT INTO logs VALUES("110","4","Logged in the system.","2023-11-09 22:01:46");
INSERT INTO logs VALUES("111","4","Logged out.","2023-11-09 22:01:49");
INSERT INTO logs VALUES("112","4","Logged in the system.","2023-11-09 22:01:50");
INSERT INTO logs VALUES("113","4","Logged out.","2023-11-09 22:02:44");
INSERT INTO logs VALUES("116","4","Logged in the system.","2023-11-09 22:03:08");
INSERT INTO logs VALUES("117","4","Logged out.","2023-11-09 22:35:18");
INSERT INTO logs VALUES("118","4","Logged in the system.","2023-11-09 22:35:19");
INSERT INTO logs VALUES("119","4","Logged in the system.","2023-11-10 09:07:13");
INSERT INTO logs VALUES("120","4","Logged out.","2023-11-10 09:07:24");
INSERT INTO logs VALUES("121","4","Logged in the system.","2023-11-10 09:07:25");
INSERT INTO logs VALUES("122","4"," deleted the user [id=15].","2023-11-10 10:09:56");
INSERT INTO logs VALUES("123","4"," deleted the user [id=16].","2023-11-10 10:21:17");
INSERT INTO logs VALUES("124","4"," deleted the user [id=17].","2023-11-10 10:27:40");
INSERT INTO logs VALUES("125","4"," deleted the user [id=18].","2023-11-10 10:27:44");
INSERT INTO logs VALUES("126","4"," deleted the user [id=19].","2023-11-10 10:29:36");
INSERT INTO logs VALUES("127","4"," deleted the user [id=20].","2023-11-10 10:31:33");
INSERT INTO logs VALUES("128","4"," deleted the user [id=21].","2023-11-10 10:34:29");
INSERT INTO logs VALUES("129","4"," deleted the user [id=22].","2023-11-10 10:36:39");
INSERT INTO logs VALUES("130","4"," deleted the user [id=23].","2023-11-10 10:54:25");
INSERT INTO logs VALUES("131","4"," updated the details of [id=25] user.","2023-11-10 10:57:08");
INSERT INTO logs VALUES("132","4"," updated the details of [id=26] user.","2023-11-10 10:57:14");
INSERT INTO logs VALUES("133","4"," deleted the user [id=25].","2023-11-10 10:57:43");
INSERT INTO logs VALUES("134","4"," deleted the user [id=26].","2023-11-10 10:57:47");
INSERT INTO logs VALUES("135","4"," deleted the user [id=27].","2023-11-10 10:58:18");
INSERT INTO logs VALUES("136","4"," deleted the user [id=24].","2023-11-10 11:00:19");
INSERT INTO logs VALUES("137","4"," updated the details of [id=28] user.","2023-11-10 11:00:27");
INSERT INTO logs VALUES("138","4"," deleted the user [id=28].","2023-11-10 11:00:48");
INSERT INTO logs VALUES("139","4"," deleted the user [id=29].","2023-11-10 11:02:35");
INSERT INTO logs VALUES("140","4"," deleted the user [id=30].","2023-11-10 11:03:49");
INSERT INTO logs VALUES("141","4"," deleted the user [id=31].","2023-11-10 11:06:10");
INSERT INTO logs VALUES("142","4"," updated the details of [id=32] user","2023-11-10 11:10:20");
INSERT INTO logs VALUES("143","4"," deleted the user [id=32].","2023-11-10 11:10:36");
INSERT INTO logs VALUES("144","4"," updated the details of [id=33] user","2023-11-10 11:11:02");
INSERT INTO logs VALUES("145","4"," deleted the user [id=33].","2023-11-10 11:13:31");
INSERT INTO logs VALUES("146","4"," updated the details of [id=34] user","2023-11-10 11:14:29");
INSERT INTO logs VALUES("147","4"," deleted the user [id=34].","2023-11-10 11:14:45");
INSERT INTO logs VALUES("148","4"," updated the details of [id=35] user","2023-11-10 11:14:59");
INSERT INTO logs VALUES("149","4"," updated the details of [id=8] user","2023-11-10 11:15:18");
INSERT INTO logs VALUES("150","4"," deleted the user [id=35].","2023-11-10 11:24:45");
INSERT INTO logs VALUES("151","4"," deleted the user [id=36].","2023-11-10 11:24:48");
INSERT INTO logs VALUES("152","4"," deleted the user [id=38].","2023-11-10 11:28:56");
INSERT INTO logs VALUES("153","4"," deleted the user [id=37].","2023-11-10 11:29:00");
INSERT INTO logs VALUES("154","4"," deleted the user [id=39].","2023-11-10 11:40:49");
INSERT INTO logs VALUES("155","4"," deleted the user [id=40].","2023-11-10 11:41:08");
INSERT INTO logs VALUES("156","4","Logged in the system.","2023-11-10 14:46:54");
INSERT INTO logs VALUES("157","4"," updated the details of [id=41] user.","2023-11-10 14:47:09");
INSERT INTO logs VALUES("158","4"," deleted the user [id=41].","2023-11-10 14:47:44");
INSERT INTO logs VALUES("159","4"," deleted the user [id=42].","2023-11-10 14:49:18");
INSERT INTO logs VALUES("160","4"," updated the details of [id=43] user.","2023-11-10 14:54:47");
INSERT INTO logs VALUES("161","4"," deleted the user [id=43].","2023-11-10 14:55:06");
INSERT INTO logs VALUES("162","4"," updated the details of [id=44] user.","2023-11-10 15:02:29");
INSERT INTO logs VALUES("163","4"," deleted the user [id=44].","2023-11-10 15:02:46");
INSERT INTO logs VALUES("164","4"," deleted the user [id=45].","2023-11-10 15:04:12");
INSERT INTO logs VALUES("165","4"," deleted the user [id=46].","2023-11-10 15:05:28");
INSERT INTO logs VALUES("166","4"," deleted the user [id=47].","2023-11-10 15:12:02");
INSERT INTO logs VALUES("167","4","Logged in the system.","2023-11-10 15:59:34");
INSERT INTO logs VALUES("168","4","Logged in the system.","2023-11-12 13:46:08");
INSERT INTO logs VALUES("169","4","Logged out.","2023-11-12 13:46:10");
INSERT INTO logs VALUES("170","4","Logged in the system.","2023-11-12 13:46:12");
INSERT INTO logs VALUES("179","4","Logged in the system.","2023-11-12 14:26:55");
INSERT INTO logs VALUES("180","4","Updated the status of appointment .","2023-11-12 14:36:13");
INSERT INTO logs VALUES("181","4","Updated the status of appointment ID 57.","2023-11-12 14:37:28");
INSERT INTO logs VALUES("182","4","Updated the status of appointment (ID: 57).","2023-11-12 14:39:33");
INSERT INTO logs VALUES("183","4","Updated the status into 2 of appointment (ID: 57).","2023-11-12 14:40:49");
INSERT INTO logs VALUES("184","4","Updated the status into 0 of appointment (ID: 57, Code: ).","2023-11-12 14:43:43");
INSERT INTO logs VALUES("185","4","Updated the status into 0 of appointment (ID: 57, Code: ).","2023-11-12 14:43:45");
INSERT INTO logs VALUES("186","4","Updated the status into 2 of appointment ID: 57, Code: .","2023-11-12 14:44:40");
INSERT INTO logs VALUES("187","4","Updated the status to 0 of appointment (ID: 57, Code: ).","2023-11-12 14:48:02");
INSERT INTO logs VALUES("188","4","Updated the status into 2 of appointment ID: 57.","2023-11-12 14:48:39");
INSERT INTO logs VALUES("189","4","Delete appointment ID: 57.","2023-11-12 14:57:20");
INSERT INTO logs VALUES("190","4","Deleted the appointment ID: 58.","2023-11-12 14:58:27");
INSERT INTO logs VALUES("193","4","Updated the status into  of appointment ID: .","2023-11-12 15:36:42");
INSERT INTO logs VALUES("194","4","Added Walkin appointment.","2023-11-12 15:37:13");
INSERT INTO logs VALUES("195","4","Added Walkin appointment.","2023-11-12 15:42:03");
INSERT INTO logs VALUES("196","4","Added Walkin appointment.","2023-11-12 15:46:37");
INSERT INTO logs VALUES("197","4","Added Walkin appointment.","2023-11-12 15:47:25");
INSERT INTO logs VALUES("198","4","Added Walkin appointment.","2023-11-12 15:56:21");
INSERT INTO logs VALUES("199","4","Added Walkin appointment.","2023-11-12 15:58:58");
INSERT INTO logs VALUES("200","4","Added Walkin appointment.","2023-11-12 16:00:27");
INSERT INTO logs VALUES("201","4","Deleted [id=54] from walkin list.","2023-11-12 16:00:28");
INSERT INTO logs VALUES("202","4","Added Walkin appointment.","2023-11-12 16:01:51");
INSERT INTO logs VALUES("203","4","Deleted [id=55] from walkin list.","2023-11-12 16:01:53");
INSERT INTO logs VALUES("204","4","Logged out.","2023-11-12 17:11:30");
INSERT INTO logs VALUES("205","4","Logged in the system.","2023-11-12 17:16:11");
INSERT INTO logs VALUES("206","4","Logged in the system.","2023-11-12 17:16:15");
INSERT INTO logs VALUES("207","4","Logged out.","2023-11-12 17:47:21");
INSERT INTO logs VALUES("208","4","Logged in the system.","2023-11-12 17:47:23");
INSERT INTO logs VALUES("209","4","Deleted the appointment ID: 59.","2023-11-12 18:02:05");
INSERT INTO logs VALUES("210","4","Logged in the system.","2023-11-12 20:52:07");
INSERT INTO logs VALUES("211","4","Added Walkin appointment.","2023-11-12 21:41:57");
INSERT INTO logs VALUES("212","4","Deleted [id=56] from walkin list.","2023-11-12 21:41:58");
INSERT INTO logs VALUES("213","4","Logged out.","2023-11-13 00:35:28");
INSERT INTO logs VALUES("220","4","Logged in the system.","2023-11-13 00:42:28");
INSERT INTO logs VALUES("221","4","Logged out.","2023-11-13 00:42:30");
INSERT INTO logs VALUES("222","4","Logged in the system.","2023-11-13 00:44:40");
INSERT INTO logs VALUES("223","4","Logged out.","2023-11-13 00:44:42");
INSERT INTO logs VALUES("224","4","Logged in the system.","2023-11-13 00:45:07");
INSERT INTO logs VALUES("225","4","Logged out.","2023-11-13 00:45:09");
INSERT INTO logs VALUES("226","4","Logged in the system.","2023-11-13 00:46:07");
INSERT INTO logs VALUES("227","4","Logged out.","2023-11-13 00:46:12");
INSERT INTO logs VALUES("228","4","Logged in the system.","2023-11-13 00:47:05");
INSERT INTO logs VALUES("229","4","Logged out.","2023-11-13 00:47:07");
INSERT INTO logs VALUES("230","4","Logged in the system.","2023-11-13 00:53:21");
INSERT INTO logs VALUES("231","4","Logged out.","2023-11-13 00:53:25");
INSERT INTO logs VALUES("232","4","Logged in the system.","2023-11-13 00:54:02");
INSERT INTO logs VALUES("233","4","Logged out.","2023-11-13 00:54:04");
INSERT INTO logs VALUES("234","4","Logged in the system.","2023-11-13 00:55:04");
INSERT INTO logs VALUES("235","4","Logged out.","2023-11-13 00:55:06");
INSERT INTO logs VALUES("236","4","Logged in the system.","2023-11-13 00:56:22");
INSERT INTO logs VALUES("237","4","Logged out.","2023-11-13 00:56:24");
INSERT INTO logs VALUES("238","4","Logged in the system.","2023-11-13 00:57:15");
INSERT INTO logs VALUES("239","4","Logged out.","2023-11-13 00:57:17");
INSERT INTO logs VALUES("240","4","Logged in the system.","2023-11-13 00:59:54");
INSERT INTO logs VALUES("241","4","Logged out.","2023-11-13 00:59:56");
INSERT INTO logs VALUES("242","4","Logged in the system.","2023-11-13 01:01:05");
INSERT INTO logs VALUES("243","4","Logged out.","2023-11-13 01:01:07");
INSERT INTO logs VALUES("244","4","Logged in the system.","2023-11-13 01:03:41");
INSERT INTO logs VALUES("245","4","Logged out.","2023-11-13 01:03:42");
INSERT INTO logs VALUES("246","4","Logged in the system.","2023-11-13 01:06:48");
INSERT INTO logs VALUES("247","4","Logged out.","2023-11-13 01:06:50");
INSERT INTO logs VALUES("248","4","Logged in the system.","2023-11-13 01:07:18");
INSERT INTO logs VALUES("249","4","Logged out.","2023-11-13 01:07:20");
INSERT INTO logs VALUES("250","4","Logged in the system.","2023-11-13 01:07:50");
INSERT INTO logs VALUES("251","4","Logged out.","2023-11-13 01:07:52");
INSERT INTO logs VALUES("252","4","Logged in the system.","2023-11-13 01:08:23");
INSERT INTO logs VALUES("253","4","Logged out.","2023-11-13 01:08:25");
INSERT INTO logs VALUES("254","4","Logged in the system.","2023-11-13 01:08:48");
INSERT INTO logs VALUES("255","4","Logged out.","2023-11-13 01:18:31");
INSERT INTO logs VALUES("256","4","Logged in the system.","2023-11-13 01:19:10");
INSERT INTO logs VALUES("257","4","Logged out.","2023-11-13 01:20:19");
INSERT INTO logs VALUES("258","4","Logged in the system.","2023-11-13 01:20:49");
INSERT INTO logs VALUES("259","4","Logged out.","2023-11-13 01:20:58");
INSERT INTO logs VALUES("260","4","Logged in the system.","2023-11-13 01:21:00");
INSERT INTO logs VALUES("261","4","Logged out.","2023-11-13 01:21:29");
INSERT INTO logs VALUES("262","4","Logged in the system.","2023-11-13 01:21:30");
INSERT INTO logs VALUES("263","4","Logged out.","2023-11-13 01:21:50");
INSERT INTO logs VALUES("264","4","Logged in the system.","2023-11-13 01:21:51");
INSERT INTO logs VALUES("265","4","Logged out.","2023-11-13 01:24:12");
INSERT INTO logs VALUES("266","4","Logged in the system.","2023-11-13 01:24:14");
INSERT INTO logs VALUES("267","4","Logged out.","2023-11-13 01:27:10");
INSERT INTO logs VALUES("268","4","Logged in the system.","2023-11-13 01:29:27");
INSERT INTO logs VALUES("269","4","Logged out.","2023-11-13 01:29:29");
INSERT INTO logs VALUES("270","4","Logged in the system.","2023-11-13 01:34:12");
INSERT INTO logs VALUES("271","4","Logged out.","2023-11-13 01:34:14");
INSERT INTO logs VALUES("272","4","Logged in the system.","2023-11-13 01:44:21");
INSERT INTO logs VALUES("273","4","Logged out.","2023-11-13 01:44:23");
INSERT INTO logs VALUES("274","4","Logged in the system.","2023-11-13 01:50:57");
INSERT INTO logs VALUES("275","4","Logged out.","2023-11-13 01:50:59");
INSERT INTO logs VALUES("276","4","Logged in the system.","2023-11-13 01:51:28");
INSERT INTO logs VALUES("277","4","Logged out.","2023-11-13 01:51:44");
INSERT INTO logs VALUES("278","4","Logged in the system.","2023-11-13 01:51:45");
INSERT INTO logs VALUES("279","4","Logged in the system.","2023-11-13 13:34:15");
INSERT INTO logs VALUES("280","4","Added Walkin appointment.","2023-11-13 14:04:57");
INSERT INTO logs VALUES("281","4","Deleted [id=57] from walkin list.","2023-11-13 14:05:09");
INSERT INTO logs VALUES("282","4","Updated the status into 2 of appointment ID: 50.","2023-11-13 14:09:58");
INSERT INTO logs VALUES("283","4","Updated the status into 0 of appointment ID: 50.","2023-11-13 14:10:16");
INSERT INTO logs VALUES("284","4","Logged in the system.","2023-11-13 21:46:39");
INSERT INTO logs VALUES("285","4","Logged in the system.","2023-11-14 08:28:25");
INSERT INTO logs VALUES("286","4","Logged out.","2023-11-14 08:33:51");
INSERT INTO logs VALUES("287","4","Logged in the system.","2023-11-14 08:35:01");
INSERT INTO logs VALUES("288","4","Logged out.","2023-11-14 08:35:16");
INSERT INTO logs VALUES("289","4","Logged in the system.","2023-11-14 08:36:26");
INSERT INTO logs VALUES("290","4","Logged out.","2023-11-14 08:36:35");
INSERT INTO logs VALUES("291","4","Logged in the system.","2023-11-14 08:37:25");
INSERT INTO logs VALUES("292","4","Updated the status into 2 of appointment ID: 50.","2023-11-14 08:39:28");
INSERT INTO logs VALUES("293","4","Updated the status into 3 of appointment ID: 50.","2023-11-14 08:40:02");
INSERT INTO logs VALUES("294","4","Logged in the system.","2023-11-14 21:18:52");
INSERT INTO logs VALUES("295","4","Logged out.","2023-11-14 21:26:16");
INSERT INTO logs VALUES("296","4","Logged in the system.","2023-11-14 21:26:51");
INSERT INTO logs VALUES("297","4","Logged out.","2023-11-14 21:26:54");
INSERT INTO logs VALUES("298","4","Logged in the system.","2023-11-14 21:44:39");
INSERT INTO logs VALUES("299","4","Logged out.","2023-11-14 21:44:41");
INSERT INTO logs VALUES("300","4","Logged in the system.","2023-11-14 21:55:13");
INSERT INTO logs VALUES("301","4","Logged in the system.","2023-11-15 10:00:28");
INSERT INTO logs VALUES("302","4","Logged out.","2023-11-15 10:02:48");
INSERT INTO logs VALUES("303","4","Logged in the system.","2023-11-15 10:05:14");
INSERT INTO logs VALUES("304","4","Logged out.","2023-11-15 10:05:17");
INSERT INTO logs VALUES("305","4","Logged in the system.","2023-11-15 10:05:33");
INSERT INTO logs VALUES("306","4","Logged out.","2023-11-15 10:06:42");
INSERT INTO logs VALUES("307","5","Logged in the system.","2023-11-15 10:06:47");
INSERT INTO logs VALUES("308","5","Logged out.","2023-11-15 10:07:03");
INSERT INTO logs VALUES("309","4","Logged in the system.","2023-11-15 10:07:10");
INSERT INTO logs VALUES("310","4","Updated the status into 0 of appointment ID: 50.","2023-11-15 10:12:05");
INSERT INTO logs VALUES("311","4","Logged in the system.","2023-11-15 10:36:17");
INSERT INTO logs VALUES("312","4","Updated the status into 2 of appointment ID: 50.","2023-11-15 10:46:12");
INSERT INTO logs VALUES("313","4","Deleted [id=9] from walkin list.","2023-11-15 10:48:57");
INSERT INTO logs VALUES("314","4","Deleted [id=7] from walkin list.","2023-11-15 10:49:26");
INSERT INTO logs VALUES("315","4","Logged out.","2023-11-15 11:08:57");
INSERT INTO logs VALUES("316","4","Logged in the system.","2023-11-15 11:09:17");
INSERT INTO logs VALUES("317","4","Logged out.","2023-11-15 11:11:32");
INSERT INTO logs VALUES("318","4","Logged in the system.","2023-11-15 11:14:19");
INSERT INTO logs VALUES("319","4","Logged in the system.","2023-11-17 21:26:43");
INSERT INTO logs VALUES("320","4","Logged out.","2023-11-17 21:26:50");
INSERT INTO logs VALUES("321","4","Logged in the system.","2023-11-18 15:04:09");
INSERT INTO logs VALUES("322","4","Logged out.","2023-11-18 15:07:18");
INSERT INTO logs VALUES("323","4","Logged in the system.","2023-11-18 15:07:20");
INSERT INTO logs VALUES("324","4","Logged in the system.","2023-11-18 17:11:39");
INSERT INTO logs VALUES("325","4","Updated the status into 1 of appointment ID: 61.","2023-11-18 17:13:33");
INSERT INTO logs VALUES("326","4","Updated the status into 3 of appointment ID: 60.","2023-11-18 17:20:43");



CREATE TABLE `message_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `fullname` text NOT NULL,
  `contact` text NOT NULL,
  `email` text NOT NULL,
  `message` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;




CREATE TABLE `payment_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 = Active, 1 = Delete',
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;

INSERT INTO payment_list VALUES("7","Gcash","0","2023-06-08 20:47:27","");
INSERT INTO payment_list VALUES("8","Paymaya","0","2023-06-08 20:47:42","");



CREATE TABLE `service_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `category_ids` text NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `fee` float NOT NULL DEFAULT 0,
  `delete_flag` tinyint(4) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;

INSERT INTO service_list VALUES("7","7","Digital Printing","BellePepper Photo and Framing Studio specialize in digital printing solutions, utilizing cutting-edge technology and high-quality materials. We offer a wide range of printing options, including large-format prints, photo books, posters, and more.","1500","0","2023-06-08 20:49:51","2023-06-08 20:51:58");
INSERT INTO service_list VALUES("8","12","Photo Ops","<p>We provide professional photo ops services, ensuring the perfect capture of important events, ceremonies, and milestones. Our experienced photographers use their creative skills to immortalize memories in stunning photographs.<br></p>","5000","0","2023-06-08 20:50:42","2023-11-03 00:31:14");
INSERT INTO service_list VALUES("9","9","Framing services","<p>At BellePepper, we understand the value of preserving and showcasing memories through elegant and durable frames. Our framing services cater to various sizes and styles, offering premium double-frame glass with extra-thick frames. We ensure that each frame complements and enhances the visual appeal of the photographs or artworks.<br></p>","2000","0","2023-06-08 20:51:35","2023-06-18 15:51:59");
INSERT INTO service_list VALUES("10","11","Photoshoot, Printing, Framing","<p>BellePepper Photo and Framing Studio specialize in digital printing solutions, utilizing cutting-edge technology and high-quality materials. We offer a wide range of printing options, including large-format prints, photo books, posters, and more. W<span style="font-size: 1rem;">e understand the value of preserving and showcasing memories through elegant and durable frames. Our framing services cater to various sizes and styles, offering premium double-frame glass with extra-thick frames. We ensure that each frame complements and enhances the visual appeal of the photographs or artworks.&nbsp;</span><span style="font-size: 1rem;">We provide professional photo ops services, ensuring the perfect capture of important events, ceremonies, and milestones. Our experienced photographers use their creative skills to immortalize memories in stunning photographs.</span><br></p>","8500","0","2023-07-04 18:36:01","");
INSERT INTO service_list VALUES("11","12","123","<p>123</p>","10","1","2023-11-03 00:25:57","2023-11-03 00:26:04");



CREATE TABLE `system_info` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4;

INSERT INTO system_info VALUES("1","name","Bellepepper Studio");
INSERT INTO system_info VALUES("6","short_name","Bellepepper Studio");
INSERT INTO system_info VALUES("11","logo","uploads/logo-1699884890.png");
INSERT INTO system_info VALUES("13","user_avatar","uploads/user_avatar.jpg");
INSERT INTO system_info VALUES("14","cover","uploads/cover-1699884912.png");
INSERT INTO system_info VALUES("15","content","Array");
INSERT INTO system_info VALUES("16","email","bellepeppervidal@gmail.com");
INSERT INTO system_info VALUES("17","contact","09152118479");
INSERT INTO system_info VALUES("18","from_time","11:00");
INSERT INTO system_info VALUES("19","to_time","21:30");
INSERT INTO system_info VALUES("20","address","#14 Unit Vidal’s Residence, Brgy. Tartaria, Silang, Cavite");
INSERT INTO system_info VALUES("23","max_appointment","1");
INSERT INTO system_info VALUES("24","schedule","8:00 AM - 5:00 PM");



CREATE TABLE `uploaded_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` text NOT NULL,
  `file_path` text NOT NULL,
  `file_type` text NOT NULL,
  `appointment_ids` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `appointment` (`appointment_ids`),
  CONSTRAINT `appointment` FOREIGN KEY (`appointment_ids`) REFERENCES `appointment_list` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4;

INSERT INTO uploaded_files VALUES("85","PNP NAMES AND IMAGES.docx","../uploads/PNP NAMES AND IMAGES.docx","application/vnd.openxmlformats-officedocument.wordprocessingml.document","47");



CREATE TABLE `users` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(250) NOT NULL,
  `middlename` text DEFAULT NULL,
  `lastname` varchar(250) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `avatar` text DEFAULT NULL,
  `verify_token` text NOT NULL,
  `last_login` datetime NOT NULL DEFAULT current_timestamp(),
  `last_logout` datetime NOT NULL DEFAULT current_timestamp(),
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `status` int(1) NOT NULL DEFAULT 1 COMMENT '0=not verified, 1 = verified',
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8mb4;

INSERT INTO users VALUES("4","Jayram","","Reynaldo","jayramreynaldo@gmail.com","ca87d4dea67961b4d6e703bab8592e09","uploads/avatar-4.png?v=1686154188","c7bdd7011c45de7718503d639e3a7da8","0000-00-00 00:00:00","0000-00-00 00:00:00","1","1","2023-06-08 00:09:48","2023-11-12 17:50:31");
INSERT INTO users VALUES("5","Kian Francis","","Aquino","kianaquino10@gmail.com","d4f6a8aeed540a130844e5088a358f66","uploads/avatar-5.png?v=1686154367","af73ab307b47fa49506356b4163fcc36","0000-00-00 00:00:00","0000-00-00 00:00:00","1","1","2023-06-08 00:12:47","2023-10-07 23:04:35");
INSERT INTO users VALUES("6","Juan","","Dela Cruz","papa","7c6f5bdc16b3748b481fb5ea98bd4ace","uploads/avatar-6.png?v=1686154799","5ff08d5a31e9d561c31b4d7e265a4b90","0000-00-00 00:00:00","0000-00-00 00:00:00","2","1","2023-06-08 00:19:58","2023-10-09 22:14:57");
INSERT INTO users VALUES("8","Gio","","Jopia","giojopia59@gmail.com","202cb962ac59075b964b07152d234b70","uploads/avatar-8.png?v=1699884845","7a0b1c7c52c4bd54fc278985260af6b2","0000-00-00 00:00:00","0000-00-00 00:00:00","1","1","2023-10-07 23:03:56","2023-11-13 22:14:05");



CREATE TABLE `walk_in` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `schedule` text NOT NULL,
  `owner_name` text NOT NULL,
  `contact` text NOT NULL,
  `email` text NOT NULL,
  `quantity` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `code` varchar(100) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4;

INSERT INTO walk_in VALUES("8","2023/11/15","marian rivera","09696969699","dong@ding","1","0","","2023-11-07 10:44:12");

