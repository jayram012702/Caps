<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
<title></title>
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
</head>

<body>
<div class="row">
<div class="col-md-8 offset-md-2">
<div class="card">
<div class="card-header bg">
<h1>Backup Database</h1>
</div>
<div class="card-body">
<a href="backupdatabase/backup.php" class="btn btn-primary">Backup Database</a>
</div>
</div>
</div>
</div>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>