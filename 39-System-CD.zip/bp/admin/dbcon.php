<?php

$con = mysqli_connect("localhost","root","","bp_db");

?>