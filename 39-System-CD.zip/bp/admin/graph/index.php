
<!DOCTYPE html>
<html lang="en">
<head>
<hr class="border-info">
<div class="row">
    <div class="col-12 col-sm-12 col-md-6 col-lg-3">
        <div class="info-box bg-gradient-light shadow">
            <span class="info-box-icon bg-gradient-info elevation-1"><i class="fas fa-th-list"></i></span>

            <div class="info-box-content">
            <span class="info-box-text">Services</span>
            <span class="info-box-number text-right">
                <?php 
                    echo $conn->query("SELECT * FROM `service_list` ")->num_rows;
                ?>
            </span>
            </div>
            <!-- /.info-box-content -->
        </div>
        
        <!-- /.info-box -->
    </div>
    <div class="col-12 col-sm-12 col-md-6 col-lg-3">
        <div class="info-box bg-gradient-light shadow">
            <span class="info-box-icon bg-gradient-primary elevation-1"><i class="fas fa-calendar-day"></i></span>

            <div class="info-box-content">
            <span class="info-box-text">Pending Request</span>
            <span class="info-box-number text-right">
                <?php 
                    echo $conn->query("SELECT * FROM `appointment_list` where `status` = 0 ")->num_rows;
                ?>
            </span>
            </div>
            <!-- /.info-box-content -->
        </div>
        <!-- /.info-box -->
    </div>
    <div class="col-12 col-sm-12 col-md-6 col-lg-3">
        <div class="info-box bg-gradient-light shadow">
            <span class="info-box-icon bg-gradient-warning elevation-1"><i class="fas fa-calendar-day"></i></span>

            <div class="info-box-content">
            <span class="info-box-text">Done Request</span>
            <span class="info-box-number text-right">
                <?php 
                    echo $conn->query("SELECT * FROM `appointment_list` where `status` = 0 ")->num_rows;
                ?>
            </span>
            </div>
            <!-- /.info-box-content -->
        </div>
        <!-- /.info-box -->
    </div>
    
    <div class="col-12 col-sm-12 col-md-6 col-lg-3">
        <div class="info-box bg-gradient-light shadow">
            <span class="info-box-icon bg-gradient-success elevation-1"><i class="fas fa-calendar-day"></i></span>

            <div class="info-box-content">
            <span class="info-box-text">Confirm Request</span>
            <span class="info-box-number text-right">
                <?php 
                    echo $conn->query("SELECT * FROM `appointment_list` where `status` = 1 ")->num_rows;
                ?>
            </span>
            </div>
            <!-- /.info-box-content -->
        </div>
        <!-- /.info-box -->
    </div>
    <div class="col-12 col-sm-12 col-md-6 col-lg-3">
        <div class="info-box bg-gradient-light shadow">
            <span class="info-box-icon bg-gradient-danger elevation-1"><i class="fas fa-calendar-day"></i></span>

            <div class="info-box-content">
            <span class="info-box-text">Cancelled Request</span>
            <span class="info-box-number text-right">
                <?php 
                    echo $conn->query("SELECT * FROM `appointment_list` where `status` = 2 ")->num_rows;
                ?>
            </span>
            </div>
            <!-- /.info-box-content -->
        </div>
        <!-- /.info-box -->
    </div>
    <div class="col-12 col-sm-12 col-md-6 col-lg-3">
        <div class="info-box bg-gradient-light shadow">
            <span class="info-box-icon bg-gradient-secondary elevation-1"><i class="fas fa-calendar-day"></i></span>

            <div class="info-box-content">
            <span class="info-box-text">Archive</span>
            <span class="info-box-number text-right">
                <?php 
                    echo $conn->query("SELECT * FROM `appointment_list` where `status` = 0 ")->num_rows;
                ?>
            </span>
            </div>
            <!-- /.info-box-content -->
        </div>
        <!-- /.info-box -->
    </div>
    
    
   
    
</div>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
  
    #myChart {
      max-width: 100%;
      height: auto;     
      margin-left: 100px;
    }
    .centered {
      text-align: center;
    }
    .vertical-text {
 writing-mode: vertical-rl; 
 transform: translateY(-50%); /* Changed this line */
 text-orientation: mixed; /* For some browsers (optional) */
 float: left;
 transform: translateY(240px);
 font-size: 30px;
}


  </style>
</head>
<body>

<?php 
require_once('../classes/DBConnection.php');

// Connect to the database
$db = new DBConnection;
$con = $db->conn;

// Fetch data for all months
$datas = $con->query("
    SELECT 
      MONTHNAME(schedule) as monthname,
      SUM(quantity) as amount,
      MONTH(schedule) as month_number
    FROM appointment_list
    WHERE `status` = 3
    GROUP BY month_number
    ORDER BY month_number
");

// Initialize arrays for months and amounts
$month = [];
$amount = [];

// Initialize an array to hold month names
$allMonths = [];
for ($m = 1; $m <= 12; $m++) {
    $monthName = date('F', mktime(0, 0, 0, $m, 1));
    $allMonths[$m] = $monthName;
}

// Initialize amounts for all months as 0
$amountsForAllMonths = array_fill(1, 12, 0);

// Fetch data and update existing amounts for available months
foreach($datas as $data) {
    $month[] = $data['monthname'];
    $amount[] = $data['amount'];
    $monthNumber = $data['month_number'];
    $amountsForAllMonths[$monthNumber] = $data['amount'];
}

// Reorder the amounts according to all months
$amount = array_values($amountsForAllMonths);

// Assign month names to corresponding months
$months = array_map(function($index) use ($allMonths) {
    return $allMonths[$index];
}, array_keys($allMonths));
?>
<div class="container-sm"  style="border-radius: 3px; position: absolute; top: 300px; left:270px; background-color: white; max-width: 60%;box-shadow: 0 10px 10px rgba(0, 0, 0, 0.2);">
<h2 class="vertical-text">Quantities</h2>
<h3 class="centered">Client per Month</h3>
  <canvas id="myChart" ></canvas>
</div>
</div>
<script>
  const labels = <?php echo json_encode($months) ?>;
  const data = {
    labels: labels,
    datasets: [{
      label: 'Quantities of Schedule',
      data: <?php echo json_encode($amount) ?>,
      backgroundColor: [  
        'rgba(133, 1, 1, 0.8)',
        'rgba(128, 0, 128, 0.8)',
        'rgba(204, 204, 255, 0.8)',
        'rgba(255, 255, 255, 0.8)',
        'rgba(0, 128, 0, 0.8)',
        'rgba(128, 0, 128, 0.8)',
        'rgba(255, 0, 0, 0.8)',
        'rgba(0, 128, 0, 0.8)',
        'rgba((0, 0, 255, 0.8)',
        'rgba(255, 192, 203, 0.8)',
        'rgba(255, 255, 0, 0.8)',
        'rgba(173, 216, 230, 0.8)'
      ],
      
      borderColor: [
        'rgb(0, 0, 0, 1)',
        'rgb(0, 0, 0, 1)',
        'rgb(0, 0, 0, 1)',
        'rgb(0, 0, 0, 1)',
        'rgb(0, 0, 0, 1)',
        'rgb(0, 0, 0, 1)',
        'rgb(0, 0, 0, 1)',
        'rgb(0, 0, 0, 1)',
        'rgb(0, 0, 0, 1)',
        'rgb(0, 0, 0, 1)',
        'rgb(0, 0, 0, 1)',
        'rgb(0, 0, 0, 1)'
      ],
      borderWidth: 2
    }]
  };

  const config = {
  type: 'bar',
  data: data,
  options: {
    indexAxis: 'x', 
    responsive: true,
    plugins: {
      title: {
        display: true,
        text: ''
      }
    },
    plugins: {
      legend: {
        display: false
      },
    },
    scales: {
      y: {
        beginAtZero: true
      }
    }
  }
};

var myChart = new Chart(document.getElementById('myChart'), config);


</script>




</body>

</html>