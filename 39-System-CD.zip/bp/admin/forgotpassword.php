<!DOCTYPE html>
<?php require_once('../config.php');?>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <style>
       body {
            font-family: Arial, sans-serif;
            background-color: #DCDCDC;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: #F5F5F5;
            border-radius: 5px;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
            padding: 50px;
            width: 500px;
            height: 300px;
            text-align: center;
        }
        h2 {
            margin-bottom: 20px;
            color: #333;
            font-size: 50px;
        }
        p {
            font-size: 14px;
            color: #555;
        }
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 500px; /* Adjust the width as needed */
    height: 50px; 
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        @media screen and (max-width: 600px) {
            .container {
                width: 95%;
            }
        }
        input[type="email"] {
            width: 100%;
            padding: 20px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }


    </style>
</head>

<body>
<div class="w-100">
        <center><img src="<?= validate_image($_settings->info('logo')) ?>" alt="" id="logo-img"></center>
      
      </div>
    <div class="container">
        <h2>Forgot Password</h2>
        <p>Enter your email address below to reset your password:</p>
        <form action="resetpassword.php" method="POST">
            <input type="email" name="email" placeholder="Email Address" required><br><br>
            <input type="submit" class="singin" name="password_reset_link"value="Send Reset Password Link">
        </form>
    </div>
</body>

</html>
