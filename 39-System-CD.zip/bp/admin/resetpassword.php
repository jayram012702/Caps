
<?php
session_start();

require_once('../classes/DBConnection.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


require 'vendor/autoload.php';

$db = new DBConnection;
$con = $db->conn;

function send_password__reset($get_name, $get_email, $token)

{
    
    $mail = new PHPMailer(true);    
    $mail->isSMTP();
    $mail->isHTML(true);                                             
    $mail->Host       = 'smtp.gmail.com';                     
    $mail->SMTPAuth   = true;                                  
    $mail->Username   = 'jereynaldo@ccc.edu.ph';                     
    $mail->Password   = 'ugqa mrzt wlma dugf';                              
    $mail->SMTPSecure = "ssl";            
    $mail->Port       = 465;                                    
    $mail->Subject = 'Reset password notification';

   
    $mail->setFrom('jayramreynaldo@gmail.com', $get_name);
    $mail->addAddress($get_email);     
    $email_template="
    <h2>Hi BellePepper Employee</h2>

    <h3>Forgot your password?
    <br>
    We received a request to reset the password for your account.
    <br>
    
    </h3>
    <h3>To reset your password, click the link:
    <a href='http://localhost/bp/admin/changepassword.php?token=$token&email=$get_email'>Change Password</a></h3>
    ";
    $mail->Body = $email_template;
    $mail->send();
} 
   
if (isset($_POST['password_reset_link']))
{
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $token = md5(rand());
    $check_email = "SELECT username, firstname FROM users WHERE username ='$email' limit 1";
    $check_email_run = mysqli_query($con, $check_email);

    if (mysqli_num_rows($check_email_run) > 0)
    {
        $row = mysqli_fetch_array($check_email_run);

        $get_name = 'Belle Pepper App';
        $get_email = $row['username'];

        $update_token = "UPDATE users SET verify_token = '$token' where username ='$get_email'limit 1";
        $update_token_run = mysqli_query($con, $update_token);

        if ($update_token_run)
        {
         send_password__reset($get_name, $get_email, $token);
         $_SESSION['status'] = "We e-mailed you a password reset link";
         header("location:forgotpassword.php");
         exit(0);
        }
        else
        {
            $_SESSION['status'] = "someting went wrong. #1";
            header("location:forgotpassword.php");
            exit(0);
        }
    }
    
    else 
    {
        $_SESSION['status'] = "no email found";
        header("location:forgotpassword.php");
        exit(0);
    }

}



if(isset($_POST['password_update']))

    $token = mysqli_real_escape_string($con, $_POST['password_token']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $new_password = mysqli_real_escape_string($con, $_POST['new_password']);
    $confirm_password = mysqli_real_escape_string($con, $_POST['confirm_password']);
{
    if(!empty($token))
    {
        if(!empty($email)&& !empty($new_password)&& (!empty($confirm_password)))
        {
            $check_token = "SELECT verify_token FROM users WHERE verify_token='$token' limit 1";
            $check_token_run = mysqli_query($con, $check_token);

            if(mysqli_num_rows($check_token_run) > 0)
            {
                if($new_password == $confirm_password )
                {

                    $pass = md5($new_password);
                    
                  $update_password = "UPDATE users SET password='$pass' WHERE verify_token='$token' LIMIT 1 "; 
                  $update_password_run =mysqli_query($con, $update_password);
                
                  if($update_password_run)
                  {
                    $new_token = md5(rand())."funda"; 
                    $update_to_new_token = "UPDATE users SET verify_token='$new_token' WHERE verify_token='$token' LIMIT 1 "; 
                    $update_to_new_token_run =mysqli_query($con, $update_to_new_token);
                    $_SESSION['status'] = "New password successfully updated";

                header("location: login.php");
                exit(0);
                  }
                  else
            {
                
                $_SESSION['status'] = "Didn't Update Password Something went wrong";
                header("location:changepassword.php?token=$token &email=$email");
                exit(0);
                }
                
            }
            else
            {
                $_SESSION['status'] = "password and confirm password does not match";
                header("location:changepassword.php?token=$token &email=$email");
                exit(0);
            }
            
        }
        else
            {
                $_SESSION['status'] = "Invalid token";
                header("location:changepassword.php?token=$token &email=$email");
                exit(0);
            }
        
        }
        else
        {
        $_SESSION['status'] = "all filed are mandetory";
        header("location:changepassword.php?token=$token &email=$email");
        exit(0);

    }
}
   else
   {

    $_SESSION['status'] = "No Token Available";
    header("location:changepassword.php");
    exit(0);
   } 
}
?>