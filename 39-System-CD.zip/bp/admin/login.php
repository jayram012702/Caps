<?php
	
	if(isset($_SESSION['id']) && $_SESSION['id'] > 0){
	    header("Location:bp/classes/login.php");
	    exit;
	}
require_once('../config.php');

?>

<!DOCTYPE html>
<html lang="en" class="" style="height: auto;">
 <?php require_once('inc/header.php') ?>
<body class="hold-transition ">
  <script>
    start_loader()
  </script>
  <style>
    html, body{
      height: 100%;
    width: 100%;
    position: absolute;
    background-image: url('../uploads/Untitled-3.png');
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    box-shadow: 5px 5px;
    }
    .login-title{
      text-shadow: 2px 2px black; 
      
    }
    .card {
      width: 500px; /* Set the width as desired */
      padding: 20px; /* Adjust padding to increase size */
    }
    .form-control {
      font-size: 16px;
    }
    #login{
      flex-direction:column !important
    }
    #logo-img {
    /* Increase the height and width of the logo */
    height: 200px;
    width: 200px;
    margin: auto; /* Center horizontally */
    margin-top: 300px; 
    object-fit: contain; /* Adjust object-fit as needed */
    object-position: center center;
    border-radius: 50%; /* Use 50% for a circular shape */
  }

  #login .col-7, #login .col-5 {
    /* Ensure the columns take the entire width */
    width: 100% !important;
    max-width: unset !important;
  }

  /* Additional styling for better positioning if needed */
  .col-7 {
    display: flex;
    justify-content: center;
  }
    
  </style>
  <div class="h-500 d-flex align-items-center w-100" id="login">
  <div class="col-7 h-100 d-flex align-items-center justify-content-center">
      <div class="w-100">
        <center><img src="<?= validate_image($_settings->info('logo')) ?>" alt="" id="logo-img"></center>
      
      </div>
      
    </div>
    <div class="col-5 h-100 bg-gradient">
    
      <div class="d-flex w-100 h-100 justify-content-center align-items-center">
        <div class="card col-sm-12 col-md-6 col-lg-3 card-outline card-primary rounded-0 shadow">
          <div class="card-header rounded-0">
            <h4 class="text-purle text-center"><b>Login</b></h4>
          </div>
          <div class="card-body rounded-0">
            <form id="login-frm" action="../login.php" method="post">
              <div class="input-group mb-3">
                <input type="text" class="form-control" autofocus name="username" placeholder="Username">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <span class="fas fa-user"></span>
                  </div>
                </div>
              </div>
              <div class="input-group mb-3">
                <input type="password" class="form-control" name="password" placeholder="Password">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <span class="fas fa-lock"></span>
                  </div>
                </div>
              </div>
              <div class="col-8">
                  <a href="forgotpassword.php">Forget Password?</a>
                </div>
                <br>
                <!-- /.col -->
                <div class="d-grid gap-2">
              
                  <button type="submit" class="btn btn-primary btn-lg btn-block btn-flat">Sign In</button>
                </div>
                <!-- /.col -->
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>

<script>
$(function () {
    // Variable to keep track of failed login attempts
    var failedAttempts = 0;

    // Function to start the countdown timer
    function startCountdownTimer(countdown, button) {
        var timerInterval = setInterval(function () {
            $('#reset-timer').text(countdown);
            if (countdown <= 0) {
                clearInterval(timerInterval);
                // Optionally, you can refresh the page or enable the login button here
                button.attr('disabled', false); // Enable the button after the countdown
            }
            countdown--;
        }, 1000);

        // Disable the button during the countdown
        button.attr('disabled', true);
    }

    $('#login-frm').submit(function (e) {
        e.preventDefault();
        $('.pop_msg').remove();
        var _this = $(this);
        var _el = $('<div>');
        _el.addClass('pop_msg');
        var signInButton = _this.find('button[type="submit"]');
        signInButton.attr('disabled', true);
        signInButton.text('Logging in...');

        $.ajax({
            url: './login.php?f=login',
            method: 'POST',
            data: _this.serialize(),
            dataType: 'JSON',
            error: err => {
                console.log(err);
                signInButton.attr('disabled', false);
                signInButton.text('Sign In');

                // Increment failed login attempts
                failedAttempts++;

                // Show error message and start countdown only after three consecutive failed attempts
                if (failedAttempts >= 3) {
                    _el.addClass('alert alert-primary');
                    _el.html('An error occurred. Please try again after <span id="reset-timer">10</span> seconds.');
                    _this.prepend(_el);
                    _el.show('slow');

                    // Start the countdown timer
                    startCountdownTimer(10, signInButton);
                }
            },
            success: function (resp) {
                if (resp.status === 'success') {
                    _el.addClass('alert alert-success');
                    setTimeout(() => {
                        location.replace('./');
                    }, 2000);
                } else if (resp.status === 'max_attempts') {
                    _el.addClass('alert alert-warning');
                    _el.html('Too many failed login attempts. Please try again after <span id="reset-timer">' + resp.time_left + '</span> seconds.');

                    // Reset failed login attempts on a successful login
                    failedAttempts = 0;

                    _this.prepend(_el); // Move this line inside the 'max_attempts' condition
                    _el.show('slow');

                    // Start the countdown timer after three consecutive failed attempts
                    if (resp.time_left >= 3) {
                        startCountdownTimer(resp.time_left, signInButton);
                    }
                } else {
                    _el.addClass('alert alert-danger');
                    _el.text(resp.msg);
                    _this.prepend(_el);
                    _el.show('slow');
                }
            }
        });
    });
});

$(document).ready(function () {
    end_loader();
});



</script>
</body>
</html>