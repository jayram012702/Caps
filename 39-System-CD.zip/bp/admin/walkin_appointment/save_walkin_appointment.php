<?php
// Start the session
session_start();

// Your database connection configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bp_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to save log
function save_log($data = array()) {
    global $conn; // Use the global connection object
    // Data array parameters
    // user_id = user unique id
    // action_made = action made by the user

    if (count($data) > 0) {
        extract($data);
        $sql = "INSERT INTO `logs` (`user_id`,`action_made`) VALUES ('$user_id','$action_made')";
        $save = $conn->query($sql);
        if (!$save) {
            die($sql . " <br> ERROR:" . $conn->error);
        }
    }
    return true;
}

// Process form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $owner_name = $_POST['owner_name'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $schedule = $_POST['schedule'];
    $quantity = $_POST['quantity'];
    $status = isset($_POST['status']) ? $_POST['status'] : ''; // Define $status

    // SQL to insert data into your 'walk_in' table
    $sql = "INSERT INTO walk_in (owner_name, contact, email, schedule, quantity, date_created) 
            VALUES ('$owner_name', '$contact', '$email', '$schedule', $quantity, NOW())";

    if ($conn->query($sql) === TRUE) {
        $user_id = isset($_SESSION['id']) ? $_SESSION['id'] : 0;
        $log['user_id'] = $user_id;
        $log['action_made'] = "Added Walkin appointment.";
        // audit log
        save_log($log);
        $conn->close();
        header('Location: ' . $_SERVER['HTTP_REFERER']);
        $resp = array("success" => true, "message" => "New record created successfully");
        echo json_encode($resp);
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
$conn->close();
?>
