<?php
session_start(); // Start the session

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    // Establish your database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "bp_db";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Function to save log
    function save_log($data = array(), $conn)
    {
        // Data array parameters
        // user_id = user unique id
        // action_made = action made by the user

        if (count($data) > 0) {
            extract($data);
            $sql = "INSERT INTO `logs` (`user_id`,`action_made`) VALUES ('$user_id','$action_made')";
            $save = $conn->query($sql);
            if (!$save) {
                die($sql . " <br> ERROR:" . $conn->error);
            }
        }
        return true;
    }

    // Escape the input to prevent SQL injection
    $appointmentID = $conn->real_escape_string($_POST['id']);

    // SQL query to delete the appointment based on the ID
    $sql = "DELETE FROM walk_in WHERE id = $appointmentID";

    if ($conn->query($sql) === TRUE) {
        // Assuming $_SESSION['id'] is set elsewhere in your code
        $log['user_id'] = $_SESSION['id'];
        $log['action_made'] = "Deleted [id=$appointmentID] from walkin list.";

        // audit log
        save_log($log, $conn);

        $conn->close();

        $resp['status'] = 'success';
        $resp['msg'] = 'Appointment deleted successfully';
        echo json_encode($resp);
        header('Location: ' . $_SERVER['HTTP_REFERER']);
        exit;
        
    } else {
        $conn->close();

        $resp['status'] = 'failed';
        $resp['msg'] = 'Failed to delete appointment.';
        $resp['error'] = $conn->error;
        echo json_encode($resp);
        exit;
    }
} else {
    echo "Invalid request";
}
?>
