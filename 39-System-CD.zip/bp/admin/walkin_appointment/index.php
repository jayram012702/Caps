
<head>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap4.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.bootstrap4.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.colVis.min.js"></script>
</head>


<div class="card card-outline card-primary">
	<div class="card-header">
		<h3 class="card-title">List of Walk-In Schedules</h3>
	</div>
	<div class="card-body">
		<div class="container-fluid">
        <div class="container-fluid">
        <table id="example" class="table table-hover table-striped table-bordered">
    <colgroup>
        <col width="5%">
        <col width="5%">
        <col width="5%">
        <col width="5%">
        <col width="5%">
        <col width="5%">
        <col width="5%">
        <col width="5%">
    </colgroup>
    <thead>
        <tr>
            <th>#</th>
            <th>Date Created</th>
            <th>Schedule</th>
            <th>Name</th>
            <th>Contact</th>
            <th>Email</th>
            <th>Quantity</th>
            <th>Action</th> <!-- New column for Delete button -->
        </tr>
    </thead>
    <tbody>
        <?php 
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "bp_db";
        
        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $i = 1;
        $qry = $conn->query("SELECT * from `walk_in` WHERE `status` <= 2 order by unix_timestamp(`date_created`) desc ");
        while($row = $qry->fetch_assoc()):
        ?>
        <tr>
            <td class="text-center"><?php echo $i++; ?></td>
            <td class=""><?php echo date("Y-m-d H:i", strtotime($row['date_created'])) ?></td>   
            <td><?php echo $row['schedule']; ?></td>         
            <td class=""><p class="truncate-1"><?php echo ucwords($row['owner_name']) ?></p></td>
            <td><?php echo $row['contact']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['quantity']; ?></td>
<form id="deleteForm" method="post" action="walkin_appointment/walkin_deletion.php" onsubmit="return confirm('Are you sure you want to delete this record?');">
    <td align="center">
        <button type="submit" class="btn btn-danger delete-appointment" name="id" value="<?php echo $row['id']; ?>">Delete</button>
    </td>
</form>


        </tr>
        <?php endwhile; ?>
    </tbody>
</table>

		</div>
		</div>
	</div>
</div>

<style>
 .required > span {
    color: red;
}
</style>
<div class="card-body">
    <!-- Existing table content here -->
    <button type="button" class="btn btn-primary" id="walkInButton" data-toggle="modal" data-target="#addAppointmentModal">
        Add Walk-In Schedules
    </button>
</div>

<!-- Modal -->
<div class="modal" id="addAppointmentModal" tabindex="-1" role="dialog" aria-labelledby="addAppointmentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content rounded-0">
            <div class="modal-header">
                <h5 class="modal-title" id="addAppointmentModalLabel">Appointment Form</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="walkin_appointment/save_walkin_appointment.php" id="appointment-form" method="POST">
                    <input type="hidden" name="id" value="<?php echo isset($id) ? $id : ''; ?>">
                    <hr>
                    <div class="row">
                        <div class="col-md-6">
                            <fieldset>
                                <legend class="text-muted">Personal Information</legend>
                                <div class="form-groupform-control-lg">
                                    <label for="owner_name" class="control-label required">Name<span>*</span></label>
                                    <input type="text" name="owner_name" id="owner_name" class="form-control form-control-border" value="<?php echo isset($owner_name) ? $owner_name : ''; ?>" required placeholder="Firstname M.I Lastname">
                                </div>
                                <div class="form-group">
                                    <label for="contact" class="control-label required">Mobile Number<span>*</span></label>
                                    <input type="text" maxlength="11" name="contact" id="contact" class="form-control form-control-border" value="<?php echo isset($contact) ? $contact : '' ?>" oninput="validateNumber(this);" required placeholder=" 09x-xxxx-xxxx">
                    </div>
                                <div class="form-group">
                                    <label for="email" class="control-label required">Email<span>*</span></label>
                                    <input type="email" name="email" id="email" class="form-control form-control-border" value="<?php echo isset($email) ? $email : ''; ?>" required placeholder="name@email.com">
                                </div>
                                <div class="form-group">
                                <label for="schedule" class="control-label required">Schedule<span>*</span></label>
                                <input type="date" name="schedule" id="schedule" class="form-control form-control-sm rounded-0" value="<?php echo isset($schedule) ? $schedule : ''; ?>"required>
                            </div>
                                <div>                                
                                    <label for="quantity" class="control-label required">Quantity<span>*</span></label>
                                    <input type="text" maxlength="3" id="quantity" name="quantity" class="form-control form-control-border" min="0" max="999" value="<?php echo isset($quantity) ? $quantity : ''; ?>" required placeholder="Number of Packs">
                                    <script>    
                                      function validateNumber(input) {
    // Remove non-numeric characters from the input
    input.value = input.value.replace(/\D/g, '');
}                             
document.getElementById('quantity').addEventListener('input', function () {
        // Check if the input value is negative
        if (/^-?\d*$/.test(this.value)) {
        // Only allow positive numbers or an empty field
        if (parseInt(this.value) < 1) {
            this.value = ''; // If the value is negative, set it to an empty string
        }
    } else {
        // Clear the field if it contains non-numeric characters
        this.value = '';
    }
});
                                    </script>
                                </div>
                                <br>
                                
                                <input type="submit"class="btn btn-primary btn-lg btn-block btn-flat" value="Submit" id="submitForm">
                                
                            </fieldset>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>






   






<script>
    
    var table = $('#example').DataTable( {
        lengthChange: false,
        buttons: [ 'copy', 'csv', 'excel', 'pdf', 'print']
    } );
 
    table.buttons().container()
        .appendTo( '#example_wrapper .col-md-6:eq(0)' );

    function validateNumber(input) {
    // Remove non-numeric characters from the input
    input.value = input.value.replace(/\D/g, '');
}
      $(document).ready(function() {
        $("#walkInButton").click(function() {
            $("#addAppointmentModal").modal("show");
        });arguments
    });


    // Get the textarea element
    const scheduleTextarea = document.getElementById('schedule');

    // Set a default text
    scheduleTextarea.value = 'yyyy/mm/dd';

    // When the user focuses on the textarea, if the value is the default text, clear it
    scheduleTextarea.addEventListener('focus', function() {
        if (scheduleTextarea.value === 'yyyy/mm/dd') {
            scheduleTextarea.value = '';
        }
    });

    // When the textarea loses focus, if the value is empty, reset the default text
    scheduleTextarea.addEventListener('blur', function() {
        if (scheduleTextarea.value === '') {
            scheduleTextarea.value = 'yyyy/mm/dd';
        }
    });
</script>
